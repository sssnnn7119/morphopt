
import os
import sys

sys.path.append(os.getcwd())
sys.path.append('..//Modules/FEA')

import torch

a = torch.linspace(0, 128, 1)

for i in range(128):
            
            p_index = i // 64
            ratio = ((i // 32) % 2) == 0
            
            print('i: %d, p_index: %d, ratio: %s' % (i, p_index, ratio))