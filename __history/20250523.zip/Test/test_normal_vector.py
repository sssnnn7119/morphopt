
import os
import sys

sys.path.append(os.getcwd())
sys.path.append('..//Modules/FEA')

import torch
from MorphOpt import GLOBAL
from MorphOpt.OptLoop import Controller
from MorphOpt.ModelParams import Surfaces, Loads, Materials
from MorphOpt import Initialize
from MorphOpt import Solve
from MorphOpt.Update.Surface import UpdateSurface
from MorphOpt.Update.Updaters import Updaters
from MorphOpt import GenerateModel
from MorphOpt.ModelParams import Params as _Params
from CPGEO.utils import mlab_visualization

from mayavi import mlab

torch.set_default_dtype(torch.float64)

surf = Surfaces.CPGEO.initialize_Cylinder(seed_size=1., 
                                                                flip=False, 
                                                                r0=4, 
                                                                length=14, 
                                                                init_location=[0,0,10],
                                                                symmetric=[0], 
                                                                MaxC=1.)
surf.load('Z:/Surface-1_iter-7')
# surf.model._build_trees()
# surf.model.pre_load(1)

geo = surf.model

surf.initialize()

# import torch
# from CPGEO.utils import mlab_visualization
# surf = params.surfaces.surface_list[1]
r, rdu, rdu2 = surf.get_geometry_values()

normal = torch.cross(rdu[:, 1], rdu[:, 0])
normal = normal / normal.norm(dim=0)

normal_P0 = torch.cross(surf.model.cp_vertices[:, surf.model.cp_elements[:, 1]] - surf.model.cp_vertices[:, surf.model.cp_elements[:, 0]],
                        surf.model.cp_vertices[:, surf.model.cp_elements[:, 2]] - surf.model.cp_vertices[:, surf.model.cp_elements[:, 0]], dim=0)
normal_P0 = normal_P0 / normal_P0.norm(dim=0)

P0_mid = (surf.model.cp_vertices[:, surf.model.cp_elements[:, 0]] + surf.model.cp_vertices[:, surf.model.cp_elements[:, 1]] + surf.model.cp_vertices[:, surf.model.cp_elements[:, 2]]) / 3

normal_Knots = torch.cross(surf.model.knots[:, surf.model.cp_elements[:, 1]] - surf.model.knots[:, surf.model.cp_elements[:, 0]],
                        surf.model.knots[:, surf.model.cp_elements[:, 2]] - surf.model.knots[:, surf.model.cp_elements[:, 0]], dim=0)
normal_Knots = normal_Knots / normal_Knots.norm(dim=0)

Knots_mid = (surf.model.knots[:, surf.model.cp_elements[:, 0]] + surf.model.knots[:, surf.model.cp_elements[:, 1]] + surf.model.knots[:, surf.model.cp_elements[:, 2]]) / 3

mlab_visualization.show_quiver3d(r, normal)
mlab_visualization.show_quiver3d(P0_mid, normal_P0)
mlab_visualization.show_quiver3d(Knots_mid, normal_Knots)