import os
import sys
os.environ['KMP_DUPLICATE_LIB_OK']='True'
sys.path.append(os.getcwd())
sys.path.append('..//Modules/FEA')

import torch
from MorphOpt import GLOBAL
from MorphOpt.OptLoop import Controller
from MorphOpt.ModelParams import Surfaces, Loads, Materials
from MorphOpt import Initialize
from MorphOpt import Solve
from MorphOpt.Update.Surface import UpdateSurface
from MorphOpt.Update.Updaters import Updaters
from MorphOpt import GenerateModel
from MorphOpt.ModelParams import Params as _Params



U_dim=[-2]

class Params(_Params):
    class SurfaceParams(Surfaces):

        def __init__(self):

            super().__init__(thickness=[2.5, 2.5],
                            max_step_length=[0.2, 0.2])

            self.add_surface(
                Surfaces.BSP.initialize_cylinder(r0=8.,
                                                        length=20.,
                                                        seed_size=1.,
                                                        symmetric=[0],
                                                        flip=False, maxR=0.2, maxC=2., maxFF=0.2))
            # self.add_surface(
            #     Surfaces.BSP.initialize_cylinder(
            #         r0=4.,
            #         length=14.,
            #         seed_size=1.,
            #         symmetric=[0],
            #         flip=True,
            #         init_location=[0., 0., 3.], maxR=0.2, maxC=2., maxFF=0.2))

            # self.add_surface(Surfaces.CPGEO.initialize_Cylinder(seed_size=1., 
            #                                                     flip=True, 
            #                                                     r0=4, 
            #                                                     length=14, 
            #                                                     init_location=[0,0,10],
            #                                                     symmetric=[0], 
            #                                                     MaxC=1.))
            
            self.add_surface(Surfaces.CPGEO.initialize_Sphere(seed_size=1.,
                                                              flip=True,
                                                              r0=4,
                                                              init_location=[0, 0, 10],))
            
            

    class LoadParams(Loads):
        class _Pressure(Loads.Pressures):
            def __init__(self):
                super().__init__()
                self.pressure = torch.Tensor([[0.04]])
        
        def __init__(self):
            self.pressure = self._Pressure()
            
    class MaterialParams(Materials):
        
        def __init__(self):
            super().__init__(mu=0.482, kappa=48., density=1.08e-9,)
    
    def __init__(self):
        super().__init__(surfaces=self.SurfaceParams(), loads=self.LoadParams(), materials=self.MaterialParams())

class Generator(GenerateModel.Genetrator):
    def __init__(self, surfaces: Surfaces, path_output: str = None, path_queue: str = None) -> None:
        """
        Initialize the Genetrator class.
        
        Parameters:
            surfaces (Surfaces): The surfaces of the soft robot.
            path_output (str): The path to the output directory.
            path_queue (str): The path to the queue directory.
        """
        super().__init__(seed_size=2.5, surfaces=surfaces, path_output=path_output, path_queue=path_queue)

class Solver(Solve.U_Udp_Solver):
    """
    Solver class for MorphOpt.
    This class is responsible for solving the finite element analysis (FEA) problem.
    """

    def __init__(self, loads: Loads):

        super().__init__(loads=loads, U_dim=U_dim,
                         num_process=1)

class Updater(Updaters):
    """
    Updater class for MorphOpt.
    This class is responsible for updating the design variables based on the results of the optimization process.
    """

    def __init__(self, params: Params, *args, **kwargs):
        super().__init__(surfaces=self.UpdaterSurfaces(surfaces=params.surfaces, loads=params.loads),
                         loads=None, *args, **kwargs)

    @staticmethod
    def objective_function(U: torch.Tensor, Udp: torch.Tensor, *args, **kwargs):
        return U[0,0]

    class UpdaterSurfaces(UpdateSurface.UpdaterSurfaces):
        """
        Updater class for MorphOpt.
        This class is responsible for updating the design variables based on the results of the optimization process.
        """

        def __init__(self, surfaces: Surfaces, loads: Loads):

            super().__init__(
                surfaces=surfaces,
                loads=loads,
                max_step_iter=50, U_dim=U_dim)

            self.add_objective_function(UpdateSurface.ObjectiveFuncs.Sensitivity())
            self.add_objective_function(
                UpdateSurface.ObjectiveFuncs.Fairness(surfaces=surfaces))
            self.add_objective_function(
                UpdateSurface.ObjectiveFuncs.Distance(surfaces=surfaces))
            self.add_objective_function(
                UpdateSurface.ObjectiveFuncs.Boundary.Cylinder(radius=10., height=80., bottom=0.))
    
    
if __name__ == '__main__':
    torch.set_default_dtype(torch.float64)
    torch.set_default_device('cpu')

    path_result = 'Z:/Results'

    # region Initialize the workflow
    Initialize.initialize_path(result_path=path_result)
    Initialize.initialize_history()

    params = Params()
    
    generator = Generator(surfaces=params.surfaces,path_output=GLOBAL.PATH.path_Result + '/Cache/', path_queue=GLOBAL.PATH.path_Queue)

    solver = Solver(loads=params.loads)

    updater = Updater(params=params)

    controller = Controller(params=params, generator=generator, solver=solver, updater=updater)
    controller.opt_loop()
