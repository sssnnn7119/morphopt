import os
import sys
os.environ['KMP_DUPLICATE_LIB_OK']='True'
sys.path.append(os.getcwd())
sys.path.append('..//Modules/FEA')
sys.path.append('..//Modules/bspline')

import numpy as np
import torch
from MorphOpt import GLOBAL
from MorphOpt.OptLoop import Controller
from MorphOpt.ModelParams import Surfaces, Loads, Materials
from MorphOpt import Initialize
from MorphOpt import Solve
from MorphOpt.Update.Surface import UpdateSurface
from MorphOpt.Update.Load import UpdateLoads
from MorphOpt.Update.Updaters import Updaters
from MorphOpt import GenerateModel
from MorphOpt.ModelParams import Params as _Params
from Bspline import BSP_Curve



U_dim = [-6,-5,-4]

sample_point = torch.tensor([0.0397101435024637, 0.1834346424956498, 
                             0.2033335225863733, 0.4744675900836710, 
                             0.5255324099163290, 0.7966664774136267, 
                             0.8165653575043502, 0.9602898564975363])
sample_weight = torch.tensor([0.05061426814518815, 0.11119051722668725, 
                               0.15685332293894365, 0.181341891689181, 
                               0.181341891689181, 0.15685332293894365, 
                               0.11119051722668725, 0.05061426814518815])

# sample_point = torch.tensor([0.03])
# sample_weight = torch.tensor([1.])

class Params(_Params):
    
    class SurfaceParams(Surfaces):

        def __init__(self):

            super().__init__(thickness=[2.5, 2.5],
                            max_step_length=[0.2, 0.2, 0.2, 0.2])

            self.add_surface(
                Surfaces.BSP.initialize_cylinder(r0=15.,
                                                        length=120.,
                                                        seed_size=1.,
                                                        symmetric=[0],
                                                        flip=False, maxR=0.2, maxC=2., maxFF=0.2))
            # self.add_surface(
            #     Surfaces.CS.initialize_Sphere(seed_size=1.5, flip=True, r0=4., init_location=[8,0,60]))

            # self.add_surface(
            #     Surfaces.CS.initialize_Sphere(seed_size=1.5, flip=True, r0=4., init_location=[-4,7,60]))
            
            # self.add_surface(
            #     Surfaces.CS.initialize_Sphere(seed_size=1.5, flip=True, r0=4., init_location=[-4,-7,60]))
            
            self.add_surface(
                Surfaces.CPGEO.initialize_Cylinder(seed_size=1.5, flip=True, r0=4., length=110., init_location=[8,0,60], symmetric=[0]))
            
            self.add_surface(
                Surfaces.CPGEO.initialize_Cylinder(seed_size=1.5, flip=True, r0=4., length=110., init_location=[-4,7,60], symmetric=[0]))
            
            self.add_surface(
                Surfaces.CPGEO.initialize_Cylinder(seed_size=1.5, flip=True, r0=4., length=110., init_location=[-4,-7,60], symmetric=[0]))

    class LoadParams(Loads):

        class _Pressure(Loads.Pressures):
            def __init__(self):
                super().__init__()

                p0 = torch.linspace(0, 0.06, 10).reshape([1, 10]).repeat([3, 1])
                self._pressure_bsp = BSP_Curve(P0=p0, degree=4,)
                self.max_step_length = 0.002

            def get_pressure(self):
                return self._pressure_bsp.map([sample_point], derivative=[0]).T
            
            def get_pdxi(self):
                return self._pressure_bsp.map([sample_point], derivative=[1]).T
            
            @property
            def num_variables(self) -> int:
                return self._pressure_bsp.control_points.numel()
            
            def get_parameters(self):
                return self._pressure_bsp.control_points.clone()
            
            def set_parameters(self, xlist: torch.Tensor) -> None:
                self._pressure_bsp.control_points = xlist.reshape(self._pressure_bsp.control_points.shape).detach().clone()
                
            def update_variables(self, x_change):
                delta_p = 2/torch.pi * torch.atan(x_change) * self.max_step_length
                self._pressure_bsp.control_points += delta_p.reshape(self._pressure_bsp.control_points.shape)

        def __init__(self):
            self.pressure = self._Pressure()
            
    class MaterialParams(Materials):
        
        def __init__(self):
            super().__init__(mu=0.482, kappa=48., density=1.08e-9,)
    
    def __init__(self):
        super().__init__(surfaces=self.SurfaceParams(), loads=self.LoadParams(), materials=self.MaterialParams())
    
class Generator(GenerateModel.Genetrator):
    def __init__(self, surfaces: Surfaces, path_output: str = None, path_queue: str = None) -> None:
        """
        Initialize the Genetrator class.
        
        Parameters:
            surfaces (Surfaces): The surfaces of the soft robot.
            path_output (str): The path to the output directory.
            path_queue (str): The path to the queue directory.
        """
        super().__init__(seed_size=3.5, surfaces=surfaces, path_output=path_output, path_queue=path_queue)

class Solver(Solve.U_Udp_Solver):
    """
    Solver class for MorphOpt.
    This class is responsible for solving the finite element analysis (FEA) problem.
    """

    def __init__(self, loads: Loads):

        super().__init__(loads=loads, U_dim=U_dim,
                         num_process=4)

class Updater(Updaters):
    """
    Updater class for MorphOpt.
    This class is responsible for updating the design variables based on the results of the optimization process.
    """
    def __init__(self, params: Params, *args, **kwargs):
        super().__init__(surfaces=self.UpdaterSurfaces(surfaces=params.surfaces, loads=params.loads), 
                         loads=self.UpdaterLoads(loads=params.loads), *args, **kwargs)

        p0 = torch.tensor([[-30,30], [0,0], [5,5]])
        self._target_curve = BSP_Curve(P0=p0, degree=2)
        self._target_U = self._target_curve.map([sample_point]).T
        self._target_Udxi = self._target_curve.map([sample_point], derivative=[1]).T
    

    def objective_function(self, U: torch.Tensor, Udp: torch.Tensor, *args, **kwargs):
        pdxi = self._load._loads_params.pressure.get_pdxi()
        Udxi = torch.einsum('tup, tp->tu', Udp, pdxi)
        
        target = ((U-self._target_U)**2 + (Udxi-self._target_Udxi)**2) * Udxi.norm(dim=1, keepdim=True)

        return torch.einsum('tu, t->', target, sample_weight)

    class UpdaterSurfaces(UpdateSurface.UpdaterSurfaces):
        """
        Updater class for MorphOpt.
        This class is responsible for updating the design variables based on the results of the optimization process.
        """

        def __init__(self, surfaces: Surfaces, loads: Loads):

            super().__init__(
                surfaces=surfaces,
                loads=loads,
                max_step_iter=200, U_dim=U_dim)

            self.add_objective_function(UpdateSurface.ObjectiveFuncs.Sensitivity())
            self.add_objective_function(
                UpdateSurface.ObjectiveFuncs.Fairness(surfaces=surfaces))
            self.add_objective_function(
                UpdateSurface.ObjectiveFuncs.Distance(surfaces=surfaces))
            self.add_objective_function(
                UpdateSurface.ObjectiveFuncs.Boundary.Cylinder(radius=20., height=120., bottom=0.))

        def initialize(self, iter_now, sensitivity, *args, **kwargs):
            if iter_now < 0:
                self._surfaces_params._max_step_length[0] = 0.06
                for i in range(1, len(self._surfaces_params._max_step_length)):
                    self._surfaces_params._max_step_length[i] = 0.8
            else:
                self._surfaces_params._max_step_length[0] = 0.1
                for i in range(1, len(self._surfaces_params._max_step_length)):
                    self._surfaces_params._max_step_length[i] = 0.1

            super().initialize(iter_now=iter_now, sensitivity=sensitivity, *args, **kwargs)

        def _refine_sensitivity(self, iter_now, sensitivity):
            sensitivity = super()._refine_sensitivity(iter_now, sensitivity)
            
            if iter_now % 10 < 0 and iter_now % 500 < 60:
                for ind_surf in range(1, len(sensitivity)):
                    sensitivity[ind_surf] += sensitivity[ind_surf].abs(
                    ).max() * 0.1
            return sensitivity

    class UpdaterLoads(UpdateLoads.UpdaterLoads):
        """
        Updater class for MorphOpt.
        This class is responsible for updating the design variables based on the results of the optimization process.
        """

        def __init__(self, loads: Loads):
            super().__init__(loads=loads, U_dim=U_dim, max_step_iter=50)

            self.add_objective_function(UpdateLoads.ObjectiveFuncs.SensitivityPressure(loads=loads))
            
            self.add_objective_function(UpdateLoads.ObjectiveFuncs.BoundaryPressure(loads=loads, p_max=0.06, p_min=0.))

if __name__ == '__main__':
    torch.set_default_dtype(torch.float64)
    torch.set_default_device('cuda')
    
    sample_point = sample_point.to('cuda').to(torch.float64)
    sample_weight = sample_weight.to('cuda').to(torch.float64)

    path_result = 'Z:/Results/'

    # region Initialize the workflow
    Initialize.initialize_path(result_path=path_result)
    Initialize.initialize_history()

    

    params = Params()

    generator = Generator(surfaces=params.surfaces,path_output=GLOBAL.PATH.path_Result + '/Cache/', path_queue=GLOBAL.PATH.path_Queue)

    solver = Solver(loads=params.loads)

    updater = Updater(params=params)

    controller = Controller(params=params, generator=generator, solver=solver, updater=updater)
    controller.opt_loop()
