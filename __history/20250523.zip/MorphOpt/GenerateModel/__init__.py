"""
This module contains the GenerationModel class, which is responsible for generating the geometric model of the soft robot.
"""

import datetime
import os
import shutil
import time
import numpy as np
from ..ModelParams import Surfaces

import sys

sys.path.append('..//Modules/FEA')
import FEA

class Genetrator:
    """
    This class is responsible for generating the geometric model of the soft robot.
    It uses Rhino for 3D modeling and Abaqus for finite element analysis (FEA).
    """
    
    def __init__(self, seed_size: float, surfaces: Surfaces, path_output: str = None, path_queue: str = None, ) -> None:
        """
        Initialize the Genetrator class.
        
        Parameters:
            surfaces (Surfaces): The surfaces of the soft robot.
            path_output (str): The path to the output directory.
            path_queue (str): The path to the queue directory.
        """

        self.surfaces = surfaces
        """
        Surfaces: The surfaces of the soft robot.
        """
        
        self.path_output = path_output
        """
        str: The path to the output directory.
        """
        
        self.path_queue = path_queue
        """
        str: The path to the queue directory.
        """
        
        self.seed_size = seed_size
        """
        float: The seed size for the finite element analysis (FEA).
        """
        

    def generate(self, material_para: list[float]) -> None:
        """
        This function generates the geometric model of the soft robot.
        It calls the Rhino application to generate the model and then calls Abaqus for finite element analysis (FEA).
        """
        
        # call Rhino to generate the model
        self.__class__._call_rhino(self.surfaces, self.path_output, self.path_queue)

        # call Abaqus for FEA
        self.__class__._call_Abaqus(self.surfaces, self.path_output, material_para, self.seed_size)
        
    @staticmethod
    def _call_rhino(surfaces: Surfaces, path_output: str, path_queue: str) -> None:
        """
        This function is a placeholder for calling Rhino, a 3D computer graphics and computer-aided design (CAD) application.
        It is currently not implemented.
        """
        
        # export each surface with Rhino
        que_Names = []
        for i in range(surfaces.num_surface):
            surf_name0 = '__surface-%d' % i
            name = surfaces.surface_list[i].output_data(path_output=path_output,
                                                    name_output=surf_name0,
                                                    flip=(i != 0))
            
            info = '%d\n%s\n%s' % (surfaces.surface_list[i].surf_type, path_output +
                                name, path_output + surf_name0 + '.stp')
            que_name = 'T' + datetime.datetime.now().strftime(
                "%Y%m%d%H%M%S") + '_%d.txt' % i
            with open(path_queue + que_name, 'w') as f:
                f.write(info.replace('/', '\\\\'))
            que_Names.append(path_queue + que_name)
        for que_file in que_Names:
            while os.path.exists(que_file):
                time.sleep(0.1)

    @staticmethod
    def _call_Abaqus(surfaces: Surfaces, path_output: str, material_para: list[float], seed_size: float) -> None:
        
        current_path = os.getcwd()

        shutil.copy(os.path.dirname(os.path.abspath(__file__)) + '/_Abaqus/GenModel.py', path_output)
        with open(path_output + '__FEM_Para_Base.txt', 'w') as f:

            # surface type
            f.write('Surfaces*\t')
            for sf in surfaces.surface_list:
                f.write('%d\t' % sf.surf_type)
            f.write('\n')

            # materials
            f.write(
                'Material*\t%s\t%e\t%d\t%e\t%e\n' %
                ('Rubber', material_para[0], material_para[1],
                material_para[2], material_para[3]))

            # Seed size
            f.write('SeedSize*\t%e\n' % seed_size)
        
        os.chdir(path_output)
        os.system('abaqus cae noGUI=' + path_output + '/GenModel.py')
        os.chdir(current_path)
        