import sys

import numpy as np
import torch
sys.path.append('..//Modules/FEA')
import FEA

class BaseSolver:
    """
    Base class for all solvers.
    """

    def __init__(self, name: str):
        self.name = name

    def solve(self, problem):
        """
        Solve the given problem.
        """
        raise NotImplementedError("This method should be overridden by subclasses.")
    
    @staticmethod
    def init_FEA(inp: FEA.FEA_INP) -> FEA.Main.FEA_Main:
        """
        Initialize the FEA solver.
        """
        raise NotImplementedError("This method should be overridden by subclasses.")
    
    
    @staticmethod
    def _solve_FEA(current_class: 'BaseSolver', path_result, pressure_list: list[float], U_dim: list[int]):
        """
        Solve the FEA problem.
        """
        raise NotImplementedError("This method should be overridden by subclasses.")