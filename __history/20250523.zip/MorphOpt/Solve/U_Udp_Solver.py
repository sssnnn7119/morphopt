import sys

import numpy as np
import torch
sys.path.append('..//Modules/FEA')
import FEA
import multiprocessing as mp

from ..ModelParams import Loads
from ..GLOBAL import PATH
from .BaseSolver import BaseSolver

class U_Udp_Solver(BaseSolver):
    """
    This class is responsible for solving the FEA and get the displacement of the soft robot.
    """

    
    def __init__(self, loads: Loads, U_dim: list[int], num_process: int = 4):
        """
        Initialize the Solver class with a list of pressure values.

        Parameters:
            pressure_list (list[list[float]]): A list of pressure values for the optimization problem.
            U_dim (list[int]): The dimensions of the interest for the optimization problem.
            p_dim (list[int]): The dimensions of the pressure for the optimization problem.
            num_process (int): The number of processes to use for parallel computation.
        """
        
        self.loads: Loads = loads
        """
        Pressures: An instance of the Pressures class from the ModelParams module.
        """

        self.num_process = num_process
        """
        int: The number of processes to use for parallel computation.
        """
        
        self.U_dim: list[int] = U_dim
        """
        list[int]: The dimensions of the interest for the optimization problem.
        """
        
    def solve(self):
        """
        Solve the optimization problem using the specified solver.

        Returns:
            tuple: the displacement field and its derivatives:
                - fe (FEA.Main.FEA_Main): An instance of the FEA_Main class with the given input parameters.
                - GC0 (list[torch.Tensor]): The displacement field at the reference point.
                - Udp0 (list[torch.Tensor]): The displacement field at the reference point with respect to the pressure.
                - GCv (list[torch.Tensor]): The first adjoint displacement field.
                - GCw (list[torch.Tensor]): The second adjoint displacement field.
        """

        pressure_list = self.loads.pressure.get_pressure().tolist()
                
        FE_inp = FEA.FEA_INP()
        FE_inp.Read_INP(PATH.path_Result + '/Cache/' + '/TopOptRun.inp')

        fe = self.init_FEA(FE_inp)
        mid_nodes_index = fe.elems['element-0'].get_2nd_order_point_index()
        fe.nodes[mid_nodes_index[:, 0]] = (fe.nodes[mid_nodes_index[:, 1]] + fe.nodes[mid_nodes_index[:, 2]]) / 2.0
        fe.initialize()

        # multiprocess FEA
        # self.__class__._solve_FEA(self.__class__, PATH.path_Result, pressure_list[0], self.U_dim)
        pools = mp.Pool(processes=self.num_process)
        result = []
        for i in range(len(pressure_list)):
            result.append(
                pools.apply_async(self.__class__._solve_FEA,
                                args=(self.__class__, PATH.path_Result, pressure_list[i], self.U_dim)))
        pools.close()
        pools.join()

        # get the result
        GC0 = torch.tensor([i.get()[0] for i in result], device='cpu')
        Udp0 = torch.tensor([i.get()[1] for i in result], device='cpu')
        GCv = torch.tensor([i.get()[2] for i in result], device='cpu')
        GCw = torch.tensor([i.get()[3] for i in result], device='cpu')

        return fe, GC0, Udp0, GCv, GCw
    
    @staticmethod
    def init_FEA(inp: FEA.FEA_INP) -> FEA.Main.FEA_Main:
        """
        Initialize the FEA class with the given input parameters.

        Parameters:
            inp (FEA.FEA_INP): The input parameters for the FEA class.

        Returns:
            FEA.Main.FEA_Main: An instance of the FEA_Main class with the given input parameters.
        """
        fe = FEA.from_inp(inp)

        # add loads
        i=0
        while True:
            if 'surface_%d_All' % (i + 1) not in fe.surface_sets.keys():
                break
            fe.add_load(FEA.loads.Pressure(surface_set='surface_%d_All' % (i + 1), pressure=0.),
                        name='Pressure_%d' % i)
            i += 1

        # add boundary condition
        bc_dof = np.array(
            list(inp.part['final_model'].sets_nodes['surface_0_Bottom'])) * 3
        bc_dof = np.concatenate([bc_dof, bc_dof + 1, bc_dof + 2])
        fe.add_constraint(FEA.constraints.Boundary_Condition(indexDOF=bc_dof, dispValue=0.),
                        name='BC')

        # add reference point and constraints
        rp = FEA.ReferencePoint([0., 0., fe.nodes[:, 2].max()],)
        rp_name = fe.add_reference_point(rp=rp)
        indexNodes = np.where((abs(fe.nodes[:, 2] - rp.node[2])
                                < 0.1).cpu().numpy())[0]
        fe.add_constraint(FEA.constraints.Couple(indexNodes=indexNodes, rp_name=rp_name)
        )

        return fe

    @staticmethod
    def _solve_FEA(current_class: 'U_Udp_Solver', path_result, pressure_list: list[float], U_dim: list[int]):
        import os
        os.environ['KMP_DUPLICATE_LIB_OK']='True'
        import sys
        import torch
        sys.path.append(os.getcwd())
        sys.path.append('..//Modules/FEA')
        import FEA
        import pypardiso
        import scipy.sparse as sp

        current_process_name = mp.current_process().name
        try:
            pool_id = int(current_process_name.split("-")[-1]) % 4
        except:
            pool_id = 0

        if torch.cuda.is_available():
            
            cuda_now = (pool_id-1) % torch.cuda.device_count()
            torch.set_default_device('cuda:%d' % cuda_now)
        else:
            torch.set_default_device('cpu')

        # torch.set_default_device(torch.device('cuda:0'))
        torch.set_default_dtype(torch.float64)
        torch.cuda.empty_cache()
        # construct the FEA
        FE_inp = FEA.FEA_INP()
        FE_inp.Read_INP(path_result + '/Cache/' + '/TopOptRun.inp')

        fe = current_class.init_FEA(FE_inp)

        num_pressure = len(pressure_list)
        num_surface = num_pressure + 1

        # change the load
        for j in range(len(pressure_list)):
            fe.loads['Pressure_%d' % j].pressure = pressure_list[j]

        # solve displacement 0
        mid_nodes_index = fe.elems['element-0'].get_2nd_order_point_index()
        
        fe.nodes[mid_nodes_index[:, 0]] = (fe.nodes[mid_nodes_index[:, 1]] + fe.nodes[mid_nodes_index[:, 2]]) / 2.0
        
        fe.elems['element-0'].set_order(1)
        fe.solve(tol_error=1e-1)

        fe.elems['element-0'].set_order(2)
        fe.refine_RGC()
        fe.solve(RGC0=fe.RGC, tol_error=1e-3)

        GC0 = fe.GC.clone().detach()
        K_indices, K_values = fe._assemble_Stiffness_Matrix(
                    RGC=fe._GC2RGC(fe.GC), load_percentage=1.0)[1:]

        K_sp = sp.coo_matrix((K_values.cpu().numpy(), (K_indices[0].cpu().numpy(), K_indices[1].cpu().numpy())),
                            shape=(fe.GC.shape[0], fe.GC.shape[0])).tocsr()
        K_solver = pypardiso.PyPardisoSolver()
        K_solver.factorize(K_sp)

        # calculate the jacobian
        R = torch.zeros([num_pressure, fe.RGC_list_indexStart[-1]])
        for p in range(num_pressure):
            F = torch.zeros([R.shape[1]])
            F_indice, F_values = fe.loads['Pressure_%d' % p]._get_K0_F0(fe._GC2RGC(GC0)[0])[:2]
            F.scatter_add_(0, F_indice, F_values)
            R[p, :F.numel()] = F.view([-1])
        R0 = fe.assemble_force(force=R, GC0=GC0)
        Udp0 = K_solver.solve(K_sp, R0.T.cpu().numpy())
        Udp0 = torch.from_numpy(Udp0).to(R.device).to(R.dtype).T
        # Udp0 = fe.solve_linear_perturbation(GC0=GC0, R0=R)
        
        # define the adjoint problem
        R = torch.zeros([len(U_dim), fe.RGC_list_indexStart[-1]])
        for i in range(len(U_dim)):
            R[i, U_dim[i]] = 1

        # solve adjoint problem with displacement 0
        R0 = fe.assemble_force(force=R, GC0=GC0)
        GCv = K_solver.solve(K_sp, -R0.T.cpu().numpy())
        GCv = torch.from_numpy(GCv).to(R.device).to(R.dtype).T
        # GCv = fe.solve_linear_perturbation(GC0=GC0, R0=-R)

        # get the derivative of the stiffness matrix with respect to the pressure
        # region for Kdp
        
        Kdp_indices = fe._assemble_Stiffness_Matrix(fe._GC2RGC(GC0))[1]

        function_udot = lambda u: fe._assemble_Stiffness_Matrix(fe._GC2RGC(u))[2]
        
        def get_Kdp(dim_now: int):
            def function_p0dot(p):
                p0 = fe.loads['Pressure_%d'%dim_now].pressure
                fe.loads['Pressure_%d'%dim_now].pressure = p
                result = fe._assemble_Stiffness_Matrix(fe._GC2RGC(fe.GC))[2]
                fe.loads['Pressure_%d'%dim_now].pressure = p0
                return result

            # \partial K / \partial u \cdot \partial u / \partial p
            K0_values, Kdp1_values = torch.autograd.functional.jvp(
                function_udot, GC0, Udp0[dim_now])
            
            # \partial K / \partial p
            _, Kdp2_values = torch.autograd.functional.jvp(
                function_p0dot, torch.tensor([pressure_list[dim_now]], dtype=torch.float64), torch.ones([1]))

            Kdp0_values = Kdp1_values + Kdp2_values
            Kdp0 = torch.sparse_coo_tensor(Kdp_indices, Kdp0_values).coalesce()
            return Kdp0
        
        Kdp = []
        for i in range(len(pressure_list)):
            Kdp.append(get_Kdp(i))

        # endregion

        # combine the results
        adjForce = torch.zeros([len(U_dim), len(pressure_list), fe.RGC_list_indexStart[-1]])
        for i in range(len(U_dim)):
            for j in range(len(pressure_list)):
                adjForce[i, j, fe.RGC_remain_index_flatten] = Kdp[j] @ GCv[i]

        
        # solve the second adjoint problem
        for i in range(len(pressure_list)):
            fe.loads['Pressure_%d'%i].pressure = pressure_list[i]
        f = -adjForce.reshape([len(U_dim) * len(pressure_list), -1])
        
        R0 = fe.assemble_force(force=f, GC0=GC0)
        GCw = K_solver.solve(K_sp, R0.T.cpu().numpy())
        GCw = torch.from_numpy(GCw).to(f.device).to(f.dtype).T
        # GCw = fe.solve_linear_perturbation(GC0=GC0, R0=f)
        GCw = GCw.reshape([len(U_dim), len(pressure_list), -1])  # u,p
        
        return GC0.tolist(), Udp0.tolist(), GCv.tolist(), GCw.tolist()

