

import torch


class BaseParams:
    """
    Base class for all parameter classes.
    """
    def __init__(self, **kwargs):
        """
        Initialize the parameters with the given keyword arguments.
        """
        self.__dict__.update(kwargs)

    def __repr__(self):
        """
        Return a string representation of the parameters.
        """
        return f"{self.__class__.__name__}({self.__dict__})"

    def __str__(self):
        """
        Return a string representation of the parameters.
        """
        return self.__repr__()
    
    def initialize(self) -> None:
        """
        Initialize the parameters.
        
        This method should be implemented in subclasses to initialize specific parameters.
        """
        pass
    
    def get_variables(self) -> list[torch.Tensor]:
        """
        Get the variables of the parameters.
        
        Returns:
            list[torch.Tensor]: The variables of the parameters.
        """
        raise NotImplementedError("This method should be implemented in subclasses.")
    
    def set_parameters(self, xlist: list[torch.Tensor]) -> None:
        """
        Set the parameters of the class.
        
        Args:
            xlist (list[torch.Tensor]): The new parameters for the class.
        """
        raise NotImplementedError("This method should be implemented in subclasses.")
    
    def get_parameters(self) -> list[torch.Tensor]:
        """
        Get the parameters of the class.
        
        Returns:
            list[torch.Tensor]: The parameters of the class.
        """
        raise NotImplementedError("This method should be implemented in subclasses.")
    
    def update_variables(self, x_change: torch.Tensor) -> None:
        """
        Update the variables of the class.
        
        Args:
            x_change (torch.Tensor): The change in variables.
        """
        raise NotImplementedError("This method should be implemented in subclasses.")
    
    def save(self, filepath: str) -> None:
        """
        Save the parameters to a file.
        
        Args:
            filepath (str): The name of the file to save the parameters to.
        """
        pass

    def load(self, filepath: str, iteration: int) -> None:
        """
        Load the parameters from a file.
        
        Args:
            filepath (str): The name of the file to load the parameters from.
            iteration (int): The iteration number to load.
        """
        pass
    
    def save_figure(self, filepath: str) -> None:
        """
        Save the figure of the parameters to a file.
        
        Args:
            filepath (str): The name of the file to save the figure to.
        """
        pass