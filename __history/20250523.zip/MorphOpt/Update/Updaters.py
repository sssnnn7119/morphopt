import torch
from .Surface.UpdateSurface import UpdaterSurfaces
from .Load.UpdateLoads import UpdaterLoads


class Updaters:
    """
    This class is responsible for updating the morphologies of the neurons.
    """

    def __init__(self, *args, **kwargs):
        """
        Initialize the Updaters class with a neuron object.

        Args:
            neuron: The neuron object to be updated.
        """
        self._surface: UpdaterSurfaces = None
        """
        UpdaterSurfaces: An instance of the UpdaterSurfaces class for updating the surfaces.
        """
        if 'surfaces' in kwargs:
            self._surface = kwargs['surfaces']
        self._var_surface: torch.Tensor = None
        """
        var_surface: The updated surface variables.
        """


        self._load: UpdaterLoads = None
        """
        UpdateLoads: An instance of the UpdateLoads class for updating the loads.
        """
        if 'loads' in kwargs:
            self._load = kwargs['loads']
        self._var_load: torch.Tensor = None
        """
        var_load: The updated load variables.
        """

    def objective_function(self, U: torch.Tensor, Udp: torch.Tensor, *args, **kwargs) -> torch.Tensor:
        """
        Get the sensitivity of the elements.

        Parameters:
            U (torch.Tensor): The displacement vector.
                [num_task, U]
            Udp (torch.Tensor): The Jacobian vector.
                [num_task, U, pressure]

        Returns:
            tuple: A tuple containing:
                Loss (float): The loss value.
        """
        raise NotImplementedError(
            "This method should be implemented in a subclass.")


    def update(self, FE_result) -> torch.Tensor:
        """
        Update the morphology of the neuron.
        """
        
        obj_fun = lambda U, Udp: self.objective_function(U, Udp, FE_result = FE_result)
        
        
        if self._surface is not None:
            loss_surface, self._var_surface = self._surface.update(FE_result, obj_fun=obj_fun)
        else:
            loss_surface = torch.zeros(1, dtype=torch.float64)

        if self._load is not None:
            loss_load, self._var_load = self._load.update(FE_result, obj_fun=obj_fun)
        else:
            loss_load = torch.zeros(1, dtype=torch.float64)

        return loss_surface + loss_load
    
    def update_variables(self) -> None:
        """
        Update the variables of the surfaces and loads.
        """
        if self._surface is not None:
            self._surface._surfaces_params.update_variables(x_change=self._var_surface)
        if self._load is not None:
            self._load._loads_params.update_variables(x_change=self._var_load)