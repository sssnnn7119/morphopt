from scipy import interpolate
import torch
from ...GLOBAL import PATH, History
import FEA
from .. import Optimizer
from . import ObjectiveFuncs
from ...ModelParams.Params import Params
from ...ModelParams import Surfaces, Loads, Materials
from tabulate import tabulate
from ...Solve import SolverMorph
from .._ElementSensitivity.SecondDerivativeElement import C3D10_Sensitivity
from ..BaseUpdater import BaseUpdater
from ...Solve.FE_result import FE_result


class UpdaterSurfaces(BaseUpdater):
    """
    The Updater class is responsible for updating the parameters of the optimization process.
    It contains methods to update the parameters based on the optimization algorithm used.
    """

    def __init__(self, params: Params, max_step_iter: int) -> None:
        """
        Initialize the Updater class with the given parameters.
        
        Parameters:
            surfaces (Surfaces): The surfaces object that contains the design variables.
            max_step_iter (int): The maximum number of iterations for the sub-optimization process.
            max_step_length_surf (list[float]): The maximum step length for each surface in the optimization process.
        """

        super().__init__(params)

        self.max_step_iter = max_step_iter
        """
        The maximum number of iterations for the sub-optimization process.
        """

        self.scaler = None
        """
        The scaler for the objective function.
        """

        self.obj_funcs: dict[str, ObjectiveFuncs.BaseObj] = {}
        """
        A list of penalty functions to be optimized. \n
        L = \sum_{i=1}^{n} w_i * f_i(x)
        """

        self._weight_points: list[torch.Tensor] = []
        """
        The weights for the points in the optimization process.
        """

        self.params_update: Surfaces = params.surfaces
        """
        The surfaces object that contains the design variables.
        """

    def add_objective_function(self,
                               obj_func: ObjectiveFuncs.BaseObj,
                               name: str = None) -> None:
        """
        Add an objective function to the list of objective functions.

        Parameters:
            obj_func (ObjectiveFuncs.BaseObj): The objective function to be added.
        """
        if name is None:
            name = obj_func.__class__.__name__

        extra_num = 0
        while name + '_%d' % extra_num in self.obj_funcs.keys():
            extra_num += 1

        name = name + '_%d' % extra_num
        self.obj_funcs[name] = obj_func

    def initialize(self, iter_now: int, sensitivity: list[torch.Tensor], *args,
                   **kwargs) -> None:
        """
        Initialize the parameters of the optimization process.

        Parameters:
            iter_now (int): The current iteration number.
        """

        # reset the scaler
        if iter_now % 10 == 0 or self.scaler is None:
            # get the maximum sensitivity value
            max_sensitivity = 0
            for sensitivity_surf in sensitivity:
                max_sensitivity = max(max_sensitivity,
                                      sensitivity_surf.abs().max())
            self.scaler = 10 / max_sensitivity
        sensitivity = [
            sensitivity_surf * self.scaler for sensitivity_surf in sensitivity
        ]

        # get the weights for the points in the optimization process
        self._weight_points = self.params_update.get_points_weight()

        # initialize the objective function
        r0, rdu0, rdu20 = self.params_update.get_geometry_values()
        for obj_func in self.obj_funcs.values():
            obj_func.initialize(r0=r0, rdu0=rdu0, sensitivity=sensitivity)

        # initialize the optimizer
        self.optimizer = Optimizer.LBFGS(closure=self.closure, num_limit=10)

        self.iteration_total = 0

    def closure(self, x: torch.Tensor, return_list=False) -> float:
        """
        The closure function for the optimization process.

        Parameters:
            x (torch.Tensor): The current point in the optimization process.

        Returns:
            float: The objective function value at the current point.
        """
        # save the current point
        x0 = self.params_update.get_parameters()

        # Set the design variables to the current point
        self.params_update.update_variables(x_change=x)

        # Calculate the objective function value
        r, rdu, rdu2 = self.params_update.get_geometry_values()

        obj_value = []
        for obj_func in self.obj_funcs.values():
            obj_value.append(obj_func(self._weight_points, r, rdu, rdu2))

        # enroll the design variables
        self.params_update.set_parameters(xlist=x0)

        if return_list:
            return obj_value
        else:
            return sum(obj_value)

    def update(self, fe_result: FE_result, obj_fun: callable) -> torch.Tensor:
        """
        Update the parameters of the optimization process.
        """

        # sensitivity analysis
        Loss, sensitivity = self._get_sensitivity(fe_result, obj_fun=obj_fun)
        sensitivity = self._refine_sensitivity(iter_now=History.iteration,
                                               sensitivity=sensitivity)
        for sensitivity_surf in sensitivity:
            ind_nan = torch.isnan(sensitivity_surf.view(-1))
            sensitivity_surf.view(-1)[ind_nan] = 0

        # initialize the optimizer
        self.initialize(iter_now=History.iteration, sensitivity=sensitivity)

        # update the objective function
        variables = self.params_update.get_variables().detach().clone()

        # print the information
        print("\n\n")
        print("Start updating the surfaces...")

        for iteration in range(self.max_step_iter):
            self.iteration_total += 1

            # get the current variables of the surfaces
            variables.data += self.optimizer.step(x_now=variables)

            # get current objective function value
            with torch.no_grad():
                obj_values = self.closure(x=variables, return_list=True)

            # print the objective function value
            # Print a pretty table showing objective values and iteration progress
            # Clear previous output (move cursor up and clear lines)
            if iteration > 0:
                print("\033[F\033[K" * 4, end="\r")

            headers = ["Iteration"] + ["Total"] + list(self.obj_funcs.keys())
            data = [[f"{iteration+1}/{self.max_step_iter}"] +
                    [f"{sum(obj_values).item():.6e}"] +
                    [f"{val.item():.6e}" for val in obj_values]]

            string = tabulate(data, headers=headers, tablefmt="grid")
            print(string, end="\r")

        return Loss, variables.detach().clone()

    # region sensitivity

    def _get_interpolate_points(self, *args, **kwargs):
        """
        Get the interpolated points for the design variables.

        Parameters:
        *args: Additional arguments.
        **kwargs: Additional keyword arguments.

        Returns:
            list[torch.Tensor]: The interpolated points for the design variables.
        """
        r0 = self.params_update.get_geometry_values()[0]
        interpolated_points = []
        for sf in range(self.params_update.num_surface):
            interpolated_points.append(r0[sf].cpu().numpy())
        return interpolated_points

    def _sensitivity_interpolation(
            self, Ldot: dict[str,
                             torch.Tensor], points_request: dict[str,
                                                                 torch.Tensor],
            interpolated_points: list[torch.Tensor]) -> list[torch.Tensor]:
        """
        Interpolate the sensitivity into the structural grids.
        
        Parameters:
            Ldot (dict[str, torch.Tensor]): The sensitivity values for elements gaussian points.
                [num_points, num_surface]
            points_request (dict[str, torch.Tensor]): The coordinates of the elements.
                [num_points, 3]
            interpolated_points (list[torch.Tensor]): The coordinates of the interpolation points.
                [num_surface, 3]
                
        Returns:
            list[torch.Tensor]: The interpolated sensitivity values for the structural grids.
                [num_surface, sensitivity]
        """

        # merge the origin coordinates
        Ldot = torch.cat(
            [Ldot[element_str] for element_str in points_request.keys()], dim=0)
        points_request = torch.cat(
            [points_request[element_str] for element_str in points_request.keys()],
            dim=0)

        # interpolate the sensitivity into the structral grids
        output_senNodes = []
        Part_A = 0
        for surf_index in range(len(interpolated_points)):

            Part_B = interpolate.griddata(
                points_request.reshape([-1, 3]).detach().cpu().numpy(),
                Ldot[:, surf_index].flatten().detach().cpu().numpy(),
                (interpolated_points[surf_index][0],
                 interpolated_points[surf_index][1],
                 interpolated_points[surf_index][2]),
                method='nearest',
                fill_value=0,
                rescale=True)

            output_senNodes.append(torch.tensor((Part_A + Part_B).tolist()))

        return output_senNodes

    def _get_sensitivity(
            self, fe_result: FE_result,
            obj_fun: callable) -> tuple[float, list[torch.Tensor]]:
        """
        Get the sensitivity of the design variables.

        Parameters:
            FE_result (FE_result): The result of the finite element analysis.

        Returns:
        torch.Tensor: The sensitivity of the design variables.
        """

        # Get the interpolated points for the design variables
        interpolated_points = self._get_interpolate_points()

        # Get the derivative of the objective function with respect to the displacement and Jacobian
        Loss, LdU, LdUdp = self._get_LdU_LdUdp(fe_result=fe_result,
                                               obj_fun=obj_fun)

        # Get the sensitivity of the design variables
        points_request, Ldot = self._get_shape_derivative(fe_result=fe_result,
                                                          LdU=LdU,
                                                          LdUdp=LdUdp)

        # Interpolate the sensitivity into the structural grids
        sensitivity = self._sensitivity_interpolation(Ldot, points_request,
                                                      interpolated_points)

        return Loss, sensitivity

    def _get_LdU_LdUdp(self, fe_result: FE_result,
                       obj_fun: callable) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Get the sensitivity of the design variables.
        Parameters:
            fe_result (FE_result): The result of the finite element analysis.
            obj_fun (callable): The objective function to be optimized.
        Returns:
            tuple: A tuple containing:
                - LdU (torch.Tensor): The sensitivity of the displacement vector.
                - LdUdp (torch.Tensor): The sensitivity of the Jacobian vector.
        """
        device = torch.zeros(1).device

        # Get the sensitivity of the elements
        GC0_ = fe_result.U[:, self.U_dim].detach().to(device).requires_grad_()
        Udp0_ = fe_result.Udp[:, :, self.U_dim].permute(
            [0, 2, 1]).detach().to(device).requires_grad_()
        Loss = obj_fun(U=GC0_, Udp=Udp0_)
        LdU = torch.autograd.grad(Loss,
                                  GC0_,
                                  retain_graph=True,
                                  allow_unused=True)[0]
        LdUdp = torch.autograd.grad(Loss, Udp0_, allow_unused=True)[0]

        if LdU is None:
            LdU = torch.zeros_like(GC0_)
        if LdUdp is None:
            LdUdp = torch.zeros_like(Udp0_)

        return Loss, LdU, LdUdp

    def _get_shape_derivative(
            self, fe_result: FE_result, LdU: torch.Tensor,
            LdUdp: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Get the shape derivative of the design variables.
        
        Args:
            fe_result (FE_result): The result of the finite element analysis.
            LdU (torch.Tensor): The sensitivity of the displacement vector.
            LdUdp (torch.Tensor): The sensitivity of the Jacobian vector.
            
        Returns:
            tuple: A tuple containing:
                - point_sensitivity dict[str, torch.Tensor]: The sensitivity of the design variables at the points.
                - Ldot dict[str, torch.Tensor]: The sensitivity of the design variables at the points.
        """
        
        device = torch.zeros(1).device
        pressure_list = fe_result.pressure_list.to(device)

        points_request = {}
        Ldot = {}

        for element_str in fe_result.fe.elems.keys():

            elems = fe_result.fe.elems[element_str]
            element_sensitive = C3D10_Sensitivity(
                elems_index=elems._elems_index,
                elems=elems._elems,
                fea=fe_result.fe)
            element_sensitive.set_materials(elems.materials)

            for p in range(len(pressure_list)):
                sen_U_now, sen_Udp_now = self._cal_shape_derivative_displacement_jacobian(
                    fe=fe_result.fe,
                    element_sensitive=element_sensitive,
                    pressure_list=pressure_list[p],
                    GC0=fe_result.U[p].to(device),
                    Udp0=fe_result.Udp[p].to(device),
                    GCv=fe_result.ADJu[p].to(device),
                    GCw=fe_result.ADJudp[p].to(device))

                if p == 0:
                    Ldot_now = torch.einsum('u, gesu->ges', LdU[p], sen_U_now) + \
                        torch.einsum('up, gesup->ges', LdUdp[p], sen_Udp_now)
                else:
                    Ldot_now += torch.einsum('u, gesu->ges', LdU[p], sen_U_now) + \
                        torch.einsum('up, gesup->ges', LdUdp[p], sen_Udp_now)

            points_request[element_str] = (element_sensitive.points_request)
            Ldot[element_str] = (Ldot_now.reshape([-1, Ldot_now.shape[-1]]))

        return points_request, Ldot

    def _refine_sensitivity(self, iter_now: int,
                            sensitivity: list) -> list[torch.Tensor]:

        for i in range(len(sensitivity)):
            # sensitivity_surf[i] *= 100
            if self.params_update.surface_list[i].surf_type == 0:
                index0 = (
                    self.params_update.surface_list[i].model.coordinates[0]
                    < self.params_update.surface_list[i].model.interval_size[0]
                    * 2
                ) | (self.params_update.surface_list[i].model.coordinates[0]
                     > 1 -
                     self.params_update.surface_list[i].model.interval_size[0]
                     * 2)
                sensitivity[i].data[index0.view(-1)] = 0

        return sensitivity

    # endregion

    # region shape derivative

    def _cal_shape_derivative_displacement_jacobian(
            self, fe: FEA.Main.FEA_Main, element_sensitive: C3D10_Sensitivity,
            pressure_list: list[float], GC0: torch.Tensor, Udp0: torch.Tensor,
            GCv: torch.Tensor, GCw: torch.Tensor):
        """
        calculate the shape derivative of the design variables.
        
        Parameters:
            - fe (FEA.Main.FEA_Main): The finite element analysis object.
            - GC0 (torch.Tensor): The displacement vector.
                [DoF]
            - Udp0 (torch.Tensor): The Jacobian vector.
                [num_pressure, DoF]
            - GCv (torch.Tensor): The sensitivity of velocity vector.
                [U, DoF]
            - GCw (torch.Tensor): The sensitivity of Jacobian vector.
                [U, p, DoF]
                
        Returns:
            tuple: A tuple containing:
                sen_U (torch.Tensor): The sensitivity of the displacement vector.
                    [num_gauss, num_element, num_surface, U]
                sen_Udp (torch.Tensor): The sensitivity of the Jacobian vector.
                    [num_gauss, num_element, num_surface, U, p]
        """

        num_surface = self.params_update.num_surface
        num_U = GCv.shape[0]

        # # prepare the data
        J, F, invF, Ugrad, Ugrad2, s, C = element_sensitive.sensitivity_conponent(
            fe._GC2RGC(GC0)[0])
        invFdual = torch.einsum('geij, gekl-> geijkl', invF, invF)
        invFdual2 = invFdual - invFdual.transpose(3, 5)

        # prepare the sensitivity tensors
        sen_U = torch.zeros([J.shape[0], J.shape[1], num_surface,
                             num_U])  # surface, u
        sen_Udp = torch.zeros(
            [J.shape[0], J.shape[1], num_surface, num_U,
             len(pressure_list)])  # surface, u, p

        v_gaussian = []
        vGrad_gaussian = []
        w_gaussian = []
        wGrad_gaussian = []
        for ind_target in range(num_U):
            V_now = fe._GC2RGC_linear(GCv[ind_target])[0]
            v_gaussian.append(element_sensitive.displacement(V_now))
            vGrad_gaussian.append(
                element_sensitive.gradient_displacement(V_now))

            w_gaussian.append([])
            wGrad_gaussian.append([])

            for ind_pressure in range(len(pressure_list)):
                W_now = fe._GC2RGC_linear(GCw[ind_target, ind_pressure])[0]
                w_gaussian[ind_target].append(
                    element_sensitive.displacement(W_now))
                wGrad_gaussian[ind_target].append(
                    element_sensitive.gradient_displacement(W_now))

        # calculate the sensitivity of U
        for ind_target in range(num_U):

            v = v_gaussian[ind_target]
            vGrad = vGrad_gaussian[ind_target]
            sen_U[:, :, :, ind_target] = \
                torch.einsum('geij, geji->ge', s, vGrad).unsqueeze(-1)
            sen_U[:, :, 1:, ind_target] += \
                    \
                torch.einsum('s, ge, geijnm, gej, gemni->ges', pressure_list, J, invFdual2, v, Ugrad2) + \
                    \
                torch.einsum('s, ge, geij, geji->ges', pressure_list, J, invF, vGrad)

        # calculate the sensitivity of Udp
        for ind_pressure in range(len(pressure_list)):
            Udp_now = fe._GC2RGC_linear(Udp0[ind_pressure])[0]
            Ugrad_dp = element_sensitive.gradient_displacement(Udp_now)
            Ugrad2_dp = element_sensitive.gradient_2nd_displacement(Udp_now)

            sdp = torch.einsum('geijkl, gekl->geij', C, Ugrad_dp)
            Jdp = torch.einsum('ge, gelk, gekl->ge', J, invF, Ugrad_dp)
            invFdp = -torch.einsum('geik, gelj, gekl->geij', invF, invF,
                                   Ugrad_dp)
            invFdualdp = torch.einsum('geij, gemn->geijmn', invFdp, invF)
            invFdualdp = invFdualdp + invFdualdp.transpose(2, 4).transpose(
                3, 5)
            invFdual2dp = invFdualdp - invFdualdp.transpose(3, 5)
            for ind_target in range(num_U):
                v = v_gaussian[ind_target]
                w = w_gaussian[ind_target][ind_pressure]
                vGrad = vGrad_gaussian[ind_target]
                wGrad = wGrad_gaussian[ind_target][ind_pressure]

                sen_Udp[:, :, :, ind_target, ind_pressure] = \
                    torch.einsum('geij, geji->ge', s, wGrad).unsqueeze(-1) + \
                    torch.einsum('geij, geji->ge', sdp, vGrad).unsqueeze(-1)

                sen_Udp[:, :, ind_pressure + 1, ind_target, ind_pressure] += \
                        \
                    torch.einsum('ge, geijnm, gej, gemni->ge', J, invFdual2, v, Ugrad2) + \
                        \
                    torch.einsum('ge, geij, geji->ge', J, invF, vGrad)

                sen_Udp[:, :, 1:, ind_target, ind_pressure] += \
                        \
                    torch.einsum('s, ge, geijnm, gej, gemni->ges', pressure_list, Jdp, invFdual2, v, Ugrad2) + \
                    torch.einsum('s, ge, geijnm, gej, gemni->ges', pressure_list, J, invFdual2dp, v, Ugrad2) + \
                    torch.einsum('s, ge, geijnm, gej, gemni->ges', pressure_list, J, invFdual2, w, Ugrad2) + \
                    torch.einsum('s, ge, geijnm, gej, gemni->ges', pressure_list, J, invFdual2, v, Ugrad2_dp) + \
                        \
                    torch.einsum('s, ge, geij, geji->ges', pressure_list, Jdp, invF, vGrad) + \
                    torch.einsum('s, ge, geij, geji->ges', pressure_list, J, invFdp, vGrad) + \
                    torch.einsum('s, ge, geij, geji->ges', pressure_list, J, invF, wGrad)

        return sen_U, sen_Udp

    # endregion
