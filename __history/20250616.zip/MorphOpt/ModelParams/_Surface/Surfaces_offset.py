from .Surfaces import Surfaces

class Surfaces_offset(Surfaces):
    """
    The Surfaces_offset class is a subclass of Surfaces that represents surfaces with an offset.
    It initializes the surfaces with a specified thickness and maximum step length.
    """

    def __init__(self, min_distance: list[float], thickness: float, max_step_length: list[float]):
        super().__init__(min_distance=min_distance, max_step_length=max_step_length)
        
        self.thickness = thickness
        """
        The thickness of the surfaces' shell.
        """
