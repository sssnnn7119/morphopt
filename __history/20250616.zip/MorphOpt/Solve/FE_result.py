# filepath: c:\Users\24391\OneDrive - sjtu.edu.cn\MineData\Learning\Code\Projects\MorphOpt\MorphOpt\Solve\FE_result.py
import os
import sys

import numpy as np
import torch

sys.path.append(os.path.join(os.path.dirname(os.getcwd()), 'Modules/FEA'))

import FEA
import pypardiso

    
class FE_result:
    """
    A class to store the results of the FEA solver.
    """

    def __init__(self, fe: FEA.FEA_Main, pressure_list: torch.Tensor,
                    U: torch.Tensor, Udp: torch.Tensor, GCv: torch.Tensor,
                    GCw: torch.Tensor):

        self.fe = fe
        """
        The FEA solver instance.
        """

        self.U = U
        """
        The displacement field.
        """
        
        self.Udp = Udp
        """
        The Jacobian.
        """
        
        self.ADJu = GCv
        """
        The first adjoint displacement field.
        """
        
        self.ADJudp = GCw
        """
        The second adjoint displacement field.
        """
        
        self.pressure_list = pressure_list
        """
        The pressure.
        """
        
    def __getitem__(self, key):
        """
        Get the attribute with the given key.
        
        Parameters:
            key: The key of the attribute to get.
            
        Returns:
            The attribute value.
            
        Raises:
            KeyError: If the key is not found.
        """
        if hasattr(self, key):
            return getattr(self, key)
        else:
            raise KeyError(f"'{key}' not found in FE_result")
