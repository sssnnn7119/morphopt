import os
import sys

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
sys.path.append(os.getcwd())
sys.path.append(os.path.join(os.path.dirname(os.getcwd()), 'Modules/FEA'))

import torch
from MorphOpt import GLOBAL
from MorphOpt.OptLoop import Controller
from MorphOpt.ModelParams import Surfaces_offset, Loads, BsplineMaterials
from MorphOpt import Initialize
from MorphOpt import Solve
from MorphOpt.Update.Surface import UpdateSurface_Shell
from MorphOpt.Update.Material import UpdateMaterials
from MorphOpt.Update.Updaters import Updaters
from MorphOpt import GenerateModel
from MorphOpt.ModelParams import Params as _Params

U_dim = [-2]


class Params(_Params):

    class SurfaceParams(Surfaces_offset):

        def __init__(self):

            super().__init__(min_distance=[2.5, 2.5], thickness=1., max_step_length=[0.2, 0.2])

            self.add_surface(
                Surfaces_offset.BSP.initialize_cylinder(r0=12.,
                                                 length=30.,
                                                 seed_size=1.,
                                                 symmetric=[0],
                                                 flip=False,
                                                 maxR=0.2,
                                                 maxC=2.5,
                                                 maxFF=0.2))
            # self.add_surface(
            #     Surfaces_offset.BSP.initialize_cylinder(r0=4.,
            #                                      length=14.,
            #                                      seed_size=1.,
            #                                      symmetric=[0],
            #                                      flip=True,
            #                                      init_location=[0., 0., 3.],
            #                                      maxR=0.2,
            #                                      maxC=2.,
            #                                      maxFF=0.2))

            # self.add_surface(Surfaces_offset.CPGEO.initialize_Cylinder(seed_size=1.,
            #                                                     flip=True,
            #                                                     r0=4,
            #                                                     length=14,
            #                                                     init_location=[0,0,10],
            #                                                     symmetric=[0],
            #                                                     MaxC=1.))

            self.add_surface(
                Surfaces_offset.CPGEO.initialize_Sphere(
                    seed_size=1.,
                    flip=True,
                    r0=6,
                    init_location=[0, 0, 15],
                    MaxC=1.
                ))
            
        def initialize(self, iteration):
            super().initialize(iteration)
            self.if_update[0] = False
            
    class LoadParams(Loads):

        class _Pressure(Loads.Pressures):

            def __init__(self):
                super().__init__()
                self.pressure = torch.Tensor([[0.06]])

        def __init__(self):
            self.pressure = self._Pressure()

    class MaterialParams(BsplineMaterials):

        def __init__(self):
            super().__init__(mu=5.,
                             kappa=10.,
                             min_ratio=0.001,
                             density=1.08e-9,
                             boundary=[[-20, 20], [-20, 20], [0, 20]],
                             seed_size=1.5,
                             init_density=0.01)

    def __init__(self):
        super().__init__(surfaces=self.SurfaceParams(),
                         loads=self.LoadParams(),
                         materials=self.MaterialParams())


class Generator(GenerateModel.Genetrator):

    def __init__(self,
                 surfaces: Surfaces_offset,
                 path_output: str = None,
                 path_queue: str = None) -> None:
        """
        Initialize the Genetrator class.
        
        Parameters:
            surfaces (Surfaces): The surfaces of the soft robot.
            path_output (str): The path to the output directory.
            path_queue (str): The path to the queue directory.
        """
        super().__init__(seed_size=2.5,
                         surfaces=surfaces,
                         path_output=path_output,
                         path_queue=path_queue)


class Solver(Solve.SolverMorph_Material_Shell):
    """
    Solver class for MorphOpt.
    This class is responsible for solving the finite element analysis (FEA) problem.
    """

    def __init__(self, params: Params):

        super().__init__(
            params=params,
            U_dim=U_dim,
            num_process=1,
            shell_mu=4.8,
            shell_kappa=48,
            shell_density=1.08e-9,
        )


class Updater(Updaters):
    """
    Updater class for MorphOpt.
    This class is responsible for updating the design variables based on the results of the optimization process.
    """

    def __init__(self, params: Params, *args, **kwargs):
        super().__init__(U_dim=U_dim,
                         surfaces=self.UpdaterSurfaces(params=params),
                         loads=None,
                         materials=self.UpdaterMaterials(params=params),
                         *args,
                         **kwargs)
        # self.if_update_surface = False
        self.if_update_material = False

    @staticmethod
    def objective_function(U: torch.Tensor, Udp: torch.Tensor, *args,
                           **kwargs):
        return U[0, 0]

    class UpdaterMaterials(UpdateMaterials.UpdaterMaterials):
        """
        Updater class for MorphOpt materials.
        This class is responsible for updating the material properties based on the results of the optimization process.
        """

        def __init__(self, params: Params):

            super().__init__(params=params, max_step_iter=50)
            self.add_objective_function(
                UpdateMaterials.ObjectiveFuncs.Sensitivity(
                    materials=params.materials))
            
            

    class UpdaterSurfaces(UpdateSurface_Shell.UpdaterSurface_Shell):
        """
        Updater class for MorphOpt.
        This class is responsible for updating the design variables based on the results of the optimization process.
        """

        def __init__(self, params: Params):

            super().__init__(params=params, max_step_iter=50)

            self.add_objective_function(
                UpdateSurface_Shell.ObjectiveFuncs.Sensitivity())
            self.add_objective_function(
                UpdateSurface_Shell.ObjectiveFuncs.Fairness(
                    surfaces=params.surfaces))
            # self.add_objective_function(
            #     UpdateSurface_Shell.ObjectiveFuncs.Distance(
            #         surfaces=params.surfaces))
            self.add_objective_function(
                UpdateSurface_Shell.ObjectiveFuncs.Boundary.Cylinder(radius=11.,
                                                               height=30.,
                                                               bottom=0.))


if __name__ == '__main__':
    torch.set_default_dtype(torch.float64)
    torch.set_default_device('cpu')

    path_result = 'Z:/Results'

    # region Initialize the workflow
    Initialize.initialize_path(result_path=path_result)
    Initialize.initialize_history()

    params = Params()

    generator = Generator(surfaces=params.surfaces,
                          path_output=GLOBAL.PATH.path_Result + '/Cache/',
                          path_queue=GLOBAL.PATH.path_Queue)

    solver = Solver(params=params)

    updater = Updater(params=params)

    controller = Controller(params=params,
                            generator=generator,
                            solver=solver,
                            updater=updater)
    # params.materials.plot()
    controller.opt_loop()
