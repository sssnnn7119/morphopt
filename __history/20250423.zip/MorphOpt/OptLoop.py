from . import GLOBAL
from . import Initialize
from . import GenerateModel
from . import Solve
from . import Update
from . import GenerateModel
from .ModelParams import Surfaces

class Controller:

    def opt_step(self, surfaces: Surfaces, generator: GenerateModel.Genetrator, solver: Solve.Solver,
                updater: Update.Surface.UpdateSurface.UpdaterSurfaces) -> None:
        """
        This function is the main loop for the optimization process.
        It initializes the workflow, generates the model, performs finite element analysis (FEA), and updates the surfaces.
        """

        # Generate the model
        generator.generate(material_para=GLOBAL.FE.material_para,
                            seed_size=GLOBAL.FE.seed_size)

        # Perform finite element analysis (FEA)
        FE_result = solver.solve()

        # Sensitivity analysis
        Loss, sensitivity = updater.get_sensitivity(*FE_result)
        sensitivity = updater.refine_sensitivity(
            iter_now=GLOBAL.History.iteration, sensitivity=sensitivity)

        # Update the surfaces based on the results of FEA
        
        updater.initialize(iter_now=GLOBAL.History.iteration,
                    sensitivity=sensitivity)
        updater.update()

    def opt_loop(self, surfaces: Surfaces, generator: GenerateModel.Genetrator, solver: Solve.Solver,
                updater: Update.Surface.UpdateSurface.UpdaterSurfaces) -> None:
        """
        This function runs the optimization loop for a specified number of iterations.
        It calls the opt_step function in each iteration.
        """

        while True:
            self.opt_step(surfaces=surfaces, generator=generator,
                    solver=solver,
                    updater=updater)
            GLOBAL.History.iteration += 1
            print('iteration: %d has been completed' % GLOBAL.History.iteration)
