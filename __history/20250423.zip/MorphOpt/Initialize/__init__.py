import datetime
import shutil
from .. import GLOBAL
import os

def initialize_path(opt_label: str = 'DefaultLabel', result_path: str = None) -> None:
    """
    Initialize the workflow by importing necessary modules and setting up the environment.
    """

    GLOBAL.PATH.opt_Lable = opt_label
    
    GLOBAL.PATH.path_Code = os.getcwd() + '/MorphOpt/'
    GLOBAL.PATH.path_Queue = GLOBAL.PATH.path_Code + '/GenerateModel/_Rhino/TaskQueue/'

    if result_path is None:
        result_path = os.getcwd() + '/Results/'
    
    GLOBAL.PATH.path_Result = result_path + '/T' + datetime.datetime.now().strftime(
        "%Y%m%d%H%M%S") + '_' + opt_label + '/'
        
    # create the result path if it does not exist
    os.makedirs(GLOBAL.PATH.path_Result + '/Cache/')
    
    os.makedirs(GLOBAL.PATH.path_Result + '/Log/Objective')

    os.makedirs(GLOBAL.PATH.path_Result + '/Log/Surfaces/Data')
    os.makedirs(GLOBAL.PATH.path_Result + '/Log/Surfaces/Picture')

    os.makedirs(GLOBAL.PATH.path_Result + '/Log/Deformation/Data')
    os.makedirs(GLOBAL.PATH.path_Result + '/Log/Deformation/Picture')

    os.makedirs(GLOBAL.PATH.path_Result + '/FEA')

    shutil.copytree(GLOBAL.PATH.path_Code, GLOBAL.PATH.path_Result + '/scripts/')

def initialize_history() -> None:
    """
    Initialize the history of the optimization process.
    """
    
    GLOBAL.History.iteration = 0
    GLOBAL.History.history_objective = []
    GLOBAL.History.history_time = []