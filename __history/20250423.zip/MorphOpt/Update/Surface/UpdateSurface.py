from scipy import interpolate
import torch
from .. import Optimizer
from . import ObjectiveFuncs
from ...ModelParams import Surfaces
from tabulate import tabulate
from FEA import FEA_Main
from .SecondDerivativeElement import C3D10_Sensitivity

class UpdaterSurfaces:
    """
    The Updater class is responsible for updating the parameters of the optimization process.
    It contains methods to update the parameters based on the optimization algorithm used.
    """

    def __init__(self, surfaces: Surfaces, max_step_iter: int) -> None:
        """
        Initialize the Updater class with the given parameters.
        
        Parameters:
            surfaces (Surfaces): The surfaces object that contains the design variables.
            max_step_iter (int): The maximum number of iterations for the sub-optimization process.
            max_step_length_surf (list[float]): The maximum step length for each surface in the optimization process.
        """

        self.max_step_iter = max_step_iter
        """
        The maximum number of iterations for the sub-optimization process.
        """

        self.iteration_total = 0
        """
        The total number of iterations performed in the optimization process.
        """

        self.scaler = None
        """
        The scaler for the objective function.
        """

        self.obj_funcs: dict[str, ObjectiveFuncs.BaseObj] = {}
        """
        A list of penalty functions to be optimized. \n
        L = \sum_{i=1}^{n} w_i * f_i(x)
        """

        self._weight_points: list[torch.Tensor] = []
        """
        The weights for the points in the optimization process.
        """

        self.optimizer: Optimizer.BaseOpt
        """
        The optimizer used for the optimization process.
        """

        self._surfaces: Surfaces = surfaces
        """
        The surfaces object that contains the design variables.
        """

    def add_objective_function(self,
                               obj_func: ObjectiveFuncs.BaseObj,
                               name: str = None) -> None:
        """
        Add an objective function to the list of objective functions.

        Parameters:
            obj_func (ObjectiveFuncs.BaseObj): The objective function to be added.
        """
        if name is None:
            name = obj_func.__class__.__name__

        extra_num = 0
        while name + '_%d' % extra_num in self.obj_funcs.keys():
            extra_num += 1

        name = name + '_%d' % extra_num
        self.obj_funcs[name] = obj_func

    def initialize(self, iter_now: int, sensitivity: list[torch.Tensor], *args,
                   **kwargs) -> None:
        """
        Initialize the parameters of the optimization process.

        Parameters:
            iter_now (int): The current iteration number.
        """
        if iter_now < 10:
            self._surfaces._max_step_length[0] = 0.6
            self._surfaces._max_step_length[1] = 0.6
        elif iter_now < 40:
            self._surfaces._max_step_length[0] = 0.2
            self._surfaces._max_step_length[1] = 0.2
        elif iter_now < 100:
            self._surfaces._max_step_length[0] = 0.1
            self._surfaces._max_step_length[1] = 0.1
        else:
            self._surfaces._max_step_length[0] = 0.04
            self._surfaces._max_step_length[1] = 0.04

        # get the weights for the points in the optimization process
        self._weight_points = self._surfaces.get_points_weight()

        # initialize the objective function
        r0, rdu0, rdu20 = self._surfaces.get_geometry_values()
        for obj_func in self.obj_funcs.values():
            obj_func.initialize(r0=r0, rdu0=rdu0, sensitivity=sensitivity)

        # initialize the optimizer
        self.optimizer = Optimizer.LBFGS(closure=self.closure, num_limit=10)

    def closure(self, x: torch.Tensor, return_list=False) -> float:
        """
        The closure function for the optimization process.

        Parameters:
            x (torch.Tensor): The current point in the optimization process.

        Returns:
            float: The objective function value at the current point.
        """
        # save the current point
        x0 = self._surfaces.get_surface_parameters()

        # Set the design variables to the current point
        self._surfaces.update_variables(x_change=x)

        # Calculate the objective function value
        r, rdu, rdu2 = self._surfaces.get_geometry_values()

        obj_value = []
        for obj_func in self.obj_funcs.values():
            obj_value.append(obj_func(self._weight_points, r, rdu, rdu2))

        # enroll the design variables
        self._surfaces.set_surface_parameters(xlist=x0)

        if return_list:
            return obj_value
        else:
            return sum(obj_value)

    def update(self) -> None:
        """
        Update the parameters of the optimization process.
        """
        self.iteration_total = 0

        variables = self._surfaces.get_variables().detach().clone()

        for iteration in range(self.max_step_iter):
            self.iteration_total += 1

            # get the current variables of the surfaces
            variables.data += self.optimizer.step(x_now=variables)

            # get current objective function value
            with torch.no_grad():
                obj_values = self.closure(x=variables, return_list=True)

            # print the objective function value
            # Print a pretty table showing objective values and iteration progress
            # Clear previous output (move cursor up and clear lines)
            if iteration > 0:
                print("\033[F\033[K" * 4, end="\r")

            headers = ["Iteration"] + list(self.obj_funcs.keys()) + ["Total"]
            data = [[f"{iteration+1}/{self.max_step_iter}"] +
                    [f"{val.item():.6e}" for val in obj_values] +
                    [f"{sum(obj_values).item():.6e}"]]
            print(tabulate(data, headers=headers, tablefmt="grid"), end="\r")

        self._surfaces.update_variables(x_change=variables.detach().clone())

    # region sensitivity

    def get_interpolate_points(self, *args, **kwargs):
        """
        Get the interpolated points for the design variables.

        Parameters:
        *args: Additional arguments.
        **kwargs: Additional keyword arguments.

        Returns:
            list[torch.Tensor]: The interpolated points for the design variables.
        """

        interpolated_points = []
        for sf in range(self._surfaces.num_surface):
            interpolated_points.append(
                self._surfaces.surface_list[sf].model.get_surface_value()[0]
                [0].detach().cpu().numpy())
        return interpolated_points

    def get_sensitivity_elems(self, U, Udp, Udot, Udpdot):
        """
        Get the sensitivity of the elements.

        Parameters:
            - U (torch.Tensor): The displacement vector.
                [num_task, DoF]
            - Udp (torch.Tensor): The Jacobian vector.
                [num_task, num_pressure, DoF]
            - Udot (torch.Tensor): The sensitivity of velocity vector.
                [num_task, num_gauss, num_element, num_surface, U]
            - Udpdot (torch.Tensor): The sensitivity of Jacobian vector.
                [num_task, num_gauss, num_element, num_surface, U, p]

        Returns:
            tuple: A tuple containing:
                Loss (float): The loss value.
                Ldot (torch.Tensor): The lsensitivity values for elements gaussian points.
                    [num_gauss, num_element, num_surface]
        """
        raise NotImplementedError(
            "This method should be implemented in a subclass.")

    def sensitivity_interpolation(self, sen_elems: torch.Tensor, origin_coo,
                                  int_points_surf):
        """
        Interpolate the sensitivity into the structural grids.
        
        Parameters:
            sen_elems (torch.Tensor): The sensitivity values for elements gaussian points.
                [num_gauss, num_element, num_surface]
            origin_coo (torch.Tensor): The coordinates of the elements.
                [num_gauss, num_element, 3]
            int_points_surf (list[torch.Tensor]): The coordinates of the interpolation points.
                [num_surface, 3]
                
        Returns:
            list[torch.Tensor]: The interpolated sensitivity values for the structural grids.
                [num_surface, num_gauss, num_element, U]
        """

        # interpolate the sensitivity into the structral grids
        output_senNodes = []
        Part_A = 0
        for surf_index in range(len(int_points_surf)):

            Part_B = interpolate.griddata(
                origin_coo.reshape([-1, 3]).detach().cpu().numpy(),
                sen_elems[:, :, surf_index].flatten().detach().cpu().numpy(),
                (int_points_surf[surf_index][0],
                 int_points_surf[surf_index][1],
                 int_points_surf[surf_index][2]),
                method='nearest',
                fill_value=0,
                rescale=True)

            output_senNodes.append(torch.tensor((Part_A + Part_B).tolist()))

        return output_senNodes

    def get_sensitivity(self, elems_points: torch.Tensor, U: torch.Tensor,
                        Udp: torch.Tensor, Udot: torch.Tensor,
                        Udpdot: torch.Tensor):
        """
        Get the sensitivity of the design variables.

        Parameters:
            - points_request (torch.Tensor): The points of the sensitivity.
                [num_gauss, num_element, U]
            - U (torch.Tensor): The displacement vector.
                [num_task, DoF]
            - Udp (torch.Tensor): The Jacobian vector.
                [num_task, num_pressure, DoF]
            - Udot (torch.Tensor): The sensitivity of velocity vector.
                [num_task, num_gauss, num_element, num_surface, U]
            - Udpdot (torch.Tensor): The sensitivity of Jacobian vector.
                [num_task, num_gauss, num_element, num_surface, U, p]

        Returns:
        torch.Tensor: The sensitivity of the design variables.
        """

        # Get the interpolated points for the design variables
        interpolated_points = self.get_interpolate_points()

        # Get the sensitivity of the elements
        Loss, Ldot = self.get_sensitivity_elems(U, Udp, Udot, Udpdot)

        # Interpolate the sensitivity into the structural grids
        sensitivity = self.sensitivity_interpolation(Ldot, elems_points,
                                                     interpolated_points)

        return Loss, sensitivity

    def refine_sensitivity(self, iter_now: int, sensitivity: list):

        if iter_now % 10 < 0 and iter_now % 500 < 60:

            for ind_surf in range(1, len(sensitivity)):

                max_sen = sensitivity[ind_surf].abs().max()

                index_add = (sensitivity[ind_surf]
                             > -0.08 * max_sen) & (sensitivity[ind_surf] < 0)

                sensitivity[ind_surf][index_add] += 0.08 * max_sen

        for i in range(len(sensitivity)):
            # sensitivity_surf[i] *= 100
            if self._surfaces.surface_list[i].surf_type == 0:
                index0 = (
                    self._surfaces.surface_list[i].model.coordinates[0]
                    < self._surfaces.surface_list[i].model.interval_size[0] * 2
                ) | (self._surfaces.surface_list[i].model.coordinates[0] > 1 -
                     self._surfaces.surface_list[i].model.interval_size[0] * 2)
                sensitivity[i].data[index0.view(-1)] = 0

        return sensitivity

    # endregion
