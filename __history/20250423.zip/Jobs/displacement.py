import os
import sys

sys.path.append(os.getcwd())
import torch
from MorphOpt import GLOBAL
from MorphOpt.OptLoop import Controller
from MorphOpt.ModelParams import Surfaces, Pressures
from MorphOpt import Initialize
from MorphOpt import Solve
from MorphOpt.Update.Surface import UpdateSurface
from MorphOpt import GenerateModel

torch.set_default_dtype(torch.float64)
torch.set_default_device('cuda')

class SurfaceParams(Surfaces):

    def __init__(self):

        super().__init__(thickness=[2.5, 2.5],
                         max_step_length=[0.2, 0.2])

        self.add_surface(
            Surfaces.BSP.initialize_cylinder(r0=8.,
                                                     length=80.,
                                                     seed_size=1.,
                                                     symmetric=[0],
                                                     flip=False))
        self.add_surface(
            Surfaces.BSP.initialize_cylinder(
                r0=4.,
                length=74.,
                seed_size=1.,
                symmetric=[0],
                flip=True,
                init_location=[0., 0., 3.]))

class PressureParams(Pressures):
    def get_pressure(self):
        return [[0.06]]
    
class Generator(GenerateModel.Genetrator):
    pass

class Solver(Solve.Solver):
    """
    Solver class for MorphOpt.
    This class is responsible for solving the finite element analysis (FEA) problem.
    """

    def __init__(self, pressures: Pressures):

        super().__init__(pressures=pressures,
                         path_result=GLOBAL.PATH.path_Result,
                         U_dim=[-2],
                         p_dim=[0],
                         num_process=1)

class UpdaterSurfaces(UpdateSurface.UpdaterSurfaces):
    """
    Updater class for MorphOpt.
    This class is responsible for updating the design variables based on the results of the optimization process.
    """

    def __init__(self, surfaces: Surfaces):

        super().__init__(
            surfaces=surfaces,
            max_step_iter=300)

        self.add_objective_function(UpdateSurface.ObjectiveFuncs.Sensitivity())
        self.add_objective_function(
            UpdateSurface.ObjectiveFuncs.Fairness(surfaces=surfaces))
        self.add_objective_function(
            UpdateSurface.ObjectiveFuncs.Distance(surfaces=surfaces))
        self.add_objective_function(
            UpdateSurface.ObjectiveFuncs.Boundary.Cylinder(radius=10., height=80., bottom=0.))

    def get_sensitivity_elems(self, U, Udp, Udot, Udpdot):
        return U[0, -2], Udot[0, :, :, :, 0]

if __name__ == '__main__':

    path_result = 'Z:/Results/'

    # region Initialize the workflow
    Initialize.initialize_path(result_path=path_result)
    Initialize.initialize_history()
    GLOBAL.FE.material_para = [1.08e-9, 1, 0.481606, 48.0]
    GLOBAL.FE.seed_size = 2.0

    surfaces = SurfaceParams()

    pressures = PressureParams()
    
    generator = Generator(surfaces=surfaces,path_output=GLOBAL.PATH.path_Result + '/Cache/', path_queue=GLOBAL.PATH.path_Queue)

    solver = Solver(pressures=pressures)

    updater_surface = UpdaterSurfaces(surfaces=surfaces)

    controller = Controller()
    controller.opt_loop(surfaces=surfaces, generator=generator, solver=solver, updater=updater_surface)
