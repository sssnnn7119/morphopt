from scipy import interpolate
from ...Geometric.SurfaceParams.Surfaces import Surfaces
import torch
class BaseAnalyzer:
    """
    Base class for sensitivity analysis in MorphOpt.
    This class provides a template for implementing different sensitivity analysis methods.
    """

    def __init__(self, surfaces: Surfaces):
        """
        Initialize the SensitivityBase class.

        Parameters:
        workflow (object): The workflow object that contains the design variables and objective functions.
        """
        self.surfaces = surfaces
        """
        Surfaces: The surfaces object that contains the design variables.
        """

    def get_interpolate_points(self, *args, **kwargs):
        """
        Get the interpolated points for the design variables.

        Parameters:
        *args: Additional arguments.
        **kwargs: Additional keyword arguments.

        Returns:
            list[torch.Tensor]: The interpolated points for the design variables.
        """
        
        interpolated_points = []
        for sf in range(self.surfaces.num_surface):
            interpolated_points.append(self.surfaces.surface_list[sf].model.get_surface_value()[0][0].detach().cpu().numpy())
        return interpolated_points

    def get_sensitivity_elems(self, U, Udp, Udot, Udpdot):
        """
        Get the sensitivity of the elements.

        Parameters:
            - U (torch.Tensor): The displacement vector.
                [num_task, DoF]
            - Udp (torch.Tensor): The Jacobian vector.
                [num_task, num_pressure, DoF]
            - Udot (torch.Tensor): The sensitivity of velocity vector.
                [num_task, num_gauss, num_element, num_surface, U]
            - Udpdot (torch.Tensor): The sensitivity of Jacobian vector.
                [num_task, num_gauss, num_element, num_surface, U, p]

        Returns:
            tuple: A tuple containing:
                Loss (float): The loss value.
                Ldot (list[torch.Tensor]): The list of sensitivity values for elements gaussian points.
        """
        raise NotImplementedError("This method should be implemented in a subclass.")

    def sensitivity_interpolation(self, sen_elems: torch.Tensor, origin_coo, int_points_surf):
        # interpolate the sensitivity into the structral grids
        output_senNodes = []
        Part_A = 0
        for surf_index in range(len(int_points_surf)):

            Part_B = interpolate.griddata(
                origin_coo.reshape([-1, 3]).detach().cpu().numpy(),
                sen_elems[:, :, surf_index].flatten().detach().cpu().numpy(),
                (int_points_surf[surf_index][0],
                int_points_surf[surf_index][1],
                int_points_surf[surf_index][2]),
                method='nearest', fill_value=0, rescale=True)

            output_senNodes.append(torch.tensor((Part_A + Part_B).tolist()))

        return output_senNodes

    def get_sensitivity(self, elems_points: torch.Tensor, U: torch.Tensor, Udp: torch.Tensor, Udot: torch.Tensor, Udpdot: torch.Tensor):
        """
        Get the sensitivity of the design variables.

        Parameters:
            - points_request (torch.Tensor): The points of the sensitivity.
                [num_gauss, num_element, U]
            - U (torch.Tensor): The displacement vector.
                [num_task, DoF]
            - Udp (torch.Tensor): The Jacobian vector.
                [num_task, num_pressure, DoF]
            - Udot (torch.Tensor): The sensitivity of velocity vector.
                [num_task, num_gauss, num_element, num_surface, U]
            - Udpdot (torch.Tensor): The sensitivity of Jacobian vector.
                [num_task, num_gauss, num_element, num_surface, U, p]

        Returns:
        torch.Tensor: The sensitivity of the design variables.
        """

        # Get the interpolated points for the design variables
        interpolated_points = self.get_interpolate_points()

        # Get the sensitivity of the elements
        Loss, Ldot = self.get_sensitivity_elems(U, Udp, Udot, Udpdot)

        # Interpolate the sensitivity into the structural grids
        sensitivity = self.sensitivity_interpolation(Ldot, elems_points, interpolated_points)

        return Loss, sensitivity
    
    def refine_sensitivity(self, iter_now: int, sensitivity: list):

        if iter_now % 10 < 0 and iter_now % 500 < 60:

            for ind_surf in range(1, len(sensitivity)):
                
                max_sen = sensitivity[ind_surf].abs().max()
                
                index_add = (sensitivity[ind_surf] > -0.08 * max_sen) & (
                    sensitivity[ind_surf] < 0)
                
                sensitivity[ind_surf][index_add] += 0.08 * max_sen
            
        for i in range(len(sensitivity)):
            # sensitivity_surf[i] *= 100
            if self.surfaces.surface_list[i].surf_type == 0:
                index0 = (self.surfaces.surface_list[i].model.coordinates[0] < self.surfaces.surface_list[i].model.interval_size[0] *
                        2) | (self.surfaces.surface_list[i].model.coordinates[0]
                                > 1 - self.surfaces.surface_list[i].model.interval_size[0] * 2)
                sensitivity[i].data[index0.view(-1)] = 0
                
        return sensitivity