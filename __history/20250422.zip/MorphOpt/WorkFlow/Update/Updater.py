import torch
from . import Optimizer
from . import ObjectiveFuncs
from ...Geometric.SurfaceParams.Surfaces import Surfaces
from tabulate import tabulate


class Updater:
    """
    The Updater class is responsible for updating the parameters of the optimization process.
    It contains methods to update the parameters based on the optimization algorithm used.
    """

    def __init__(self, surfaces: Surfaces) -> None:
        """
        Initialize the Updater class with the given parameters.
        """

        self.max_step_iter = 300
        """
        The maximum number of iterations for the sub-optimization process.
        """

        self.max_step_length_surfs: list[float] = [0.2 for _ in range(surfaces.num_surface)]
        """
        The maximum step length for each surface in the optimization process.
        """

        self.iteration_total = 0
        """
        The total number of iterations performed in the optimization process.
        """

        self.scaler = None
        """
        The scaler for the objective function.
        """
        
        self.obj_funcs: dict[str, ObjectiveFuncs.BaseObj] = {}
        """
        A list of penalty functions to be optimized. \n
        L = \sum_{i=1}^{n} w_i * f_i(x)
        """
        
        self.weight_points: list[torch.Tensor] = []
        """
        The weights for the points in the optimization process.
        """

        self.optimizer: Optimizer.BaseOpt
        """
        The optimizer used for the optimization process.
        """

        self.surfaces: Surfaces = surfaces
        """
        The surfaces object that contains the design variables.
        """

    def add_objective_function(self, obj_func: ObjectiveFuncs.BaseObj, name: str = None) -> None:
        """
        Add an objective function to the list of objective functions.

        Parameters:
            obj_func (ObjectiveFuncs.BaseObj): The objective function to be added.
        """
        if name is None:
            name = obj_func.__class__.__name__

        extra_num = 0
        while name+'_%d' % extra_num in self.obj_funcs.keys():
            extra_num += 1
            
        name = name+'_%d' % extra_num
        self.obj_funcs[name] = obj_func
    
    def initialize(self, iter_now: int, sensitivity: list[torch.Tensor], *args, **kwargs) -> None:
        """
        Initialize the parameters of the optimization process.

        Parameters:
            iter_now (int): The current iteration number.
        """
        if iter_now < 10:
            self.max_step_length_surfs[0] = 0.6
            self.max_step_length_surfs[1] = 0.6
        elif iter_now < 40:
            self.max_step_length_surfs[0] = 0.2
            self.max_step_length_surfs[1] = 0.2
        elif iter_now < 100:
            self.max_step_length_surfs[0] = 0.1
            self.max_step_length_surfs[1] = 0.1
        else:
            self.max_step_length_surfs[0] = 0.04
            self.max_step_length_surfs[1] = 0.04
        
        self.surfaces.max_step_length = self.max_step_length_surfs
            
        # get the weights for the points in the optimization process
        self.weight_points = self.surfaces.get_points_weight()
        
        # initialize the objective function
        r0, rdu0, rdu20 = self.surfaces.get_geometry_values()
        for obj_func in self.obj_funcs.values():
            obj_func.initialize(r0=r0, rdu0=rdu0, sensitivity=sensitivity)
        
        # initialize the optimizer
        self.optimizer = Optimizer.LBFGS(closure=self.closure, num_limit=10)
            
    def closure(self, x: torch.Tensor, return_list = False) -> float:
        """
        The closure function for the optimization process.

        Parameters:
            x (torch.Tensor): The current point in the optimization process.

        Returns:
            float: The objective function value at the current point.
        """
        # save the current point
        x0 = self.surfaces.get_surface_parameters()

        # Set the design variables to the current point
        self.surfaces.update_variables(x_change=x)

        # Calculate the objective function value
        r, rdu, rdu2 = self.surfaces.get_geometry_values()
        
        obj_value = []
        for obj_func in self.obj_funcs.values():
            obj_value.append(obj_func(self.weight_points, r, rdu, rdu2))

        # enroll the design variables
        self.surfaces.set_surface_parameters(xlist=x0)

        if return_list:
            return obj_value
        else:
            return sum(obj_value)

    def update(self) -> None:
        """
        Update the parameters of the optimization process.
        """
        self.iteration_total = 0

        variables = self.surfaces.get_variables().detach().clone()
        
        for iteration in range(self.max_step_iter):
            self.iteration_total += 1
            
            # get the current variables of the surfaces
            variables.data += self.optimizer.step(x_now=variables)
            
            # get current objective function value
            with torch.no_grad():
                obj_values = self.closure(x=variables, return_list=True)
            
            # print the objective function value
            # Print a pretty table showing objective values and iteration progress
            # Clear previous output (move cursor up and clear lines)
            if iteration > 0:
                print("\033[F\033[K" * 4, end="\r")
            
            headers = ["Iteration"] + list(self.obj_funcs.keys()) + ["Total"]
            data = [[f"{iteration+1}/{self.max_step_iter}"] + [f"{val.item():.6e}" for val in obj_values] + [f"{sum(obj_values).item():.6e}"]]
            print(tabulate(data, headers=headers, tablefmt="grid"), end="\r")
            
        self.surfaces.update_variables(x_change=variables.detach().clone())
        