import torch
from ..BaseObj import BaseObj
from .Distance_Function import Get_Neighbors
from .....Geometric.SurfaceParams.Surfaces import Surfaces


class Distance(BaseObj):
    """
    Distance objective function for MorphOpt.
    """

    def __init__(self, surfaces: Surfaces):
        """
        Initialize the Distance objective function with a name.
        """
        super().__init__()

        self.neighbor_points: torch.Tensor
        """
        The neighbor points of the surfaces that need to be checked for distance.
        """

        self.points_surface_index: torch.Tensor
        """
        The index of the surfaces for each point.
        """

        self.surfaces: Surfaces = surfaces
        """
        The surfaces object that contains the design variables.
        """

        self.neighbor_mindist: torch.Tensor
        """
        The allowable minimum distance between the points.
        """

    def initialize(self, r0, rdu0, *args, **kwargs) -> None:

        normal0 = []
        for i in range(len(r0)):
            normal_vector = torch.cross(rdu0[i][:, 1], rdu0[i][:, 0], dim=0)
            normal_vector /= normal_vector.norm(dim=0)
            normal0.append(normal_vector.detach().clone())

        num_points_total = []
        index_Surf = []
        ignored = []
        for i in range(len(r0)):
            index_Surf.append(torch.ones(r0[i].shape[1]) * i)
            num_points_total += [r0[i].shape[1]]

        normal0 = torch.cat(normal0, dim=1).type(torch.float32)
        
        self.points_surface_index = torch.cat(index_Surf,
                                              dim=0).type(torch.int64)

        self.neighbor_points = Get_Neighbors(
            points=torch.cat(r0, dim=1),
            Normal0=normal0,
            index_points=torch.cat(index_Surf, dim=0),
            size_cell=1,
            num_points_set=torch.tensor(num_points_total),
            mindistance=self.surfaces.thickness,
            max_step_length=self.surfaces.max_step_length)[0]
        self.neighbor_points = torch.tensor(self.neighbor_points, dtype=torch.int64)
        R0 = torch.cat(r0, dim=1).type(torch.float32)

        self.neighbor_mindist = torch.zeros(self.neighbor_points.shape[1], dtype=torch.float32)
        self.neighbor_mindist[self.points_surface_index[
            self.neighbor_points[0]] != self.points_surface_index[
                self.neighbor_points[1]]] = self.surfaces.thickness[1]
        
        index_same_surface = torch.where(
            self.points_surface_index[self.neighbor_points[0]] ==
            self.points_surface_index[self.neighbor_points[1]])[0]
        
        self.neighbor_mindist[index_same_surface] = self.surfaces.thickness[0] * (-normal0[:, self.neighbor_points[0][index_same_surface]] *
            normal0[:, self.neighbor_points[1][index_same_surface]]).sum(dim=0)

    def __call__(self, weight, r, rdu, rdu2, *args, **kwargs):

        R = torch.cat(r, dim=1).type(torch.float32)
        thre = 0.05
        degree = 3
        loss_distance = torch.tensor(0.0, dtype=torch.float32)
        weight_flatten = torch.cat(weight, dim=0).type(torch.float32)
        if torch.numel(self.neighbor_points) != 0:

            deltaR = R[:, self.neighbor_points[0]] - R[:,
                                                       self.neighbor_points[1]]
            distance = torch.sqrt(((deltaR)**2).sum(dim=0))

            dist = self.neighbor_mindist - distance + thre

            indexl, l = self.barrier_function(dist, thre, 0, degree)

            if len(indexl) > 0:
                loss_distance += (l * weight_flatten[self.neighbor_points[0, indexl]] *
                                  weight_flatten[self.neighbor_points[1, indexl]]).sum()
                
        return loss_distance
