
import ctypes
import os
import numpy as np
import torch
import sys

current_path = os.path.dirname(os.path.abspath(__file__))


def transform(data):
    return np.array(data.tolist())

def Get_Neighbors(points,
                  Normal0,
                  index_points,
                  size_cell,
                  mindistance,
                  max_step_length,
                  num_points_set: torch.Tensor,
                  num_of_core=8,
                  neighbor_ignored=8):
    faceApi = ctypes.WinDLL(current_path + '/src/DistancePenalty.dll')
    
    # double the ignored

    points = transform(points)
    
    Normal0 = transform(Normal0)

    index_points = transform(index_points)
    mindistance = np.array(mindistance, dtype=float)

    points = points.reshape(3, -1)

    num_points = points.shape[1]

    points_ptr = points.astype(np.float64).copy().ctypes.data_as(
        ctypes.POINTER(ctypes.c_double))
    
    Normal0_ptr = Normal0.astype(np.float64).copy().ctypes.data_as(
        ctypes.POINTER(ctypes.c_double))

    index_points_ptr = index_points.astype(np.int32).copy().ctypes.data_as(
        ctypes.POINTER(ctypes.c_int))
    mindistance_ptr = mindistance.astype(np.float64).copy().ctypes.data_as(
        ctypes.POINTER(ctypes.c_double))

    faceApi.Find_Neighbors(points_ptr, Normal0_ptr,
                           ctypes.c_double(size_cell), index_points_ptr,
                           mindistance_ptr, ctypes.c_double(np.max(np.array(max_step_length))), int(num_of_core),
                           int(num_points))
    num_connection = np.zeros([1], dtype=int)
    num_connection_ptr = num_connection.ctypes.data_as(
        ctypes.POINTER(ctypes.c_int))
    faceApi.Get_num_pair_of_points(num_connection_ptr)
    connection = np.zeros([2, num_connection[0]], dtype=int)
    connection_ptr = connection.ctypes.data_as(ctypes.POINTER(ctypes.c_int))

    mindist = np.zeros(num_connection[0], dtype=float)
    mindist_ptr = mindist.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
    faceApi.Get_pair_of_points(connection_ptr, mindist_ptr)
    
    return connection.tolist(), mindist.tolist()


