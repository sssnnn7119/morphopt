import datetime
import shutil
from ... import Params
import os

def initialize_path(opt_label: str = 'DefaultLabel', result_path: str = None) -> None:
    """
    Initialize the workflow by importing necessary modules and setting up the environment.
    """

    Params.PATH.opt_Lable = opt_label
    
    Params.PATH.path_Code = os.getcwd() + '/MorphOpt/'
    Params.PATH.path_Queue = Params.PATH.path_Code + '/WorkFlow/GenerateModel/_Rhino/TaskQueue/'

    if result_path is None:
        result_path = os.getcwd() + '/Results/'
    
    Params.PATH.path_Result = result_path + '/T' + datetime.datetime.now().strftime(
        "%Y%m%d%H%M%S") + '_' + opt_label + '/'
        
    # create the result path if it does not exist
    os.makedirs(Params.PATH.path_Result + '/Cache/')
    
    os.makedirs(Params.PATH.path_Result + '/Log/Objective')

    os.makedirs(Params.PATH.path_Result + '/Log/Surfaces/Data')
    os.makedirs(Params.PATH.path_Result + '/Log/Surfaces/Picture')

    os.makedirs(Params.PATH.path_Result + '/Log/Deformation/Data')
    os.makedirs(Params.PATH.path_Result + '/Log/Deformation/Picture')

    os.makedirs(Params.PATH.path_Result + '/FEA')

    shutil.copytree(Params.PATH.path_Code, Params.PATH.path_Result + '/scripts/')

def initialize_history() -> None:
    """
    Initialize the history of the optimization process.
    """
    
    Params.History.iteration = 0
    Params.History.history_objective = []
    Params.History.history_time = []