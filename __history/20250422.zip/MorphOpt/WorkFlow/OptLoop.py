from .. import Params
from . import Initialize
from . import GenerateModel
from . import Solve
from . import Update
from . import AnalyzeSensitivity
from ..Geometric.SurfaceParams.Surfaces import Surfaces


def opt_step(surfaces: Surfaces, solver: Solve.BaseSolver,
             analyzer: AnalyzeSensitivity.BaseAnalyzer,
             updater: Update.Updater) -> None:
    """
    This function is the main loop for the optimization process.
    It initializes the workflow, generates the model, performs finite element analysis (FEA), and updates the surfaces.
    """

    # Generate the model
    GenerateModel.generate(surfaces=surfaces,
                           path_output=Params.PATH.path_Result + '/Cache/',
                           path_queue=Params.PATH.path_Queue,
                           material_para=Params.FE.material_para,
                           seed_size=Params.FE.seed_size)

    # Perform finite element analysis (FEA)
    FE_result = solver.solve()

    # Sensitivity analysis
    Loss, sensitivity = analyzer.get_sensitivity(*FE_result)
    sensitivity = analyzer.refine_sensitivity(
        iter_now=Params.History.iteration, sensitivity=sensitivity)

    # Update the surfaces based on the results of FEA
    updater.initialize(iter_now=Params.History.iteration,
                   sensitivity=sensitivity)
    updater.update()

def opt_loop(surfaces: Surfaces, solver: Solve.BaseSolver,
             analyzer: AnalyzeSensitivity.BaseAnalyzer,
             updater: Update.Updater) -> None:
    """
    This function runs the optimization loop for a specified number of iterations.
    It calls the opt_step function in each iteration.
    """

    while True:
        opt_step(surfaces=surfaces,
                 solver=solver,
                 analyzer=analyzer,
                 updater=updater)
        Params.History.iteration += 1
        print('iteration: %d has been completed' % Params.History.iteration)
