"""
This module contains the GenerationModel class, which is responsible for generating the geometric model of the soft robot.
"""

import datetime
import os
import shutil
import time
import numpy as np
from ...Geometric.SurfaceParams.Surfaces import Surfaces

import sys

sys.path.append('..//Modules/FEA')
import FEA

def generate(surfaces: Surfaces, path_output: str, path_queue: str, material_para: list[float], seed_size: float) -> None:
    """
    This function generates the geometric model of the soft robot.
    It calls the Rhino application to generate the model and then calls Abaqus for finite element analysis (FEA).
    """
    
    # call Rhino to generate the model
    call_rhino(surfaces, path_output, path_queue)

    # call Abaqus for FEA
    call_Abaqus(surfaces, path_output, material_para, seed_size)
    

def call_rhino(surfaces: Surfaces, path_output: str, path_queue: str) -> None:
    """
    This function is a placeholder for calling Rhino, a 3D computer graphics and computer-aided design (CAD) application.
    It is currently not implemented.
    """
    
    # export each surface with Rhino
    que_Names = []
    for i in range(surfaces.num_surface):
        surf_name0 = '__surface-%d' % i
        name = surfaces.surface_list[i].output_data(path_output=path_output,
                                                name_output=surf_name0,
                                                flip=(i != 0))
        
        info = '%d\n%s\n%s' % (surfaces.surface_list[i].surf_type, path_output +
                            name, path_output + surf_name0 + '.stp')
        que_name = 'T' + datetime.datetime.now().strftime(
            "%Y%m%d%H%M%S") + '_%d.txt' % i
        with open(path_queue + que_name, 'w') as f:
            f.write(info.replace('/', '\\\\'))
        que_Names.append(path_queue + que_name)
    for que_file in que_Names:
        while os.path.exists(que_file):
            time.sleep(0.1)

def call_Abaqus(surfaces: Surfaces, path_output: str, material_para: list[float], seed_size: float) -> None:
    
    current_path = os.getcwd()
    path0 = os.path.dirname(os.path.abspath(__file__))

    shutil.copy(os.path.dirname(os.path.abspath(__file__)) + '/_Abaqus/GenModel.py', path_output)
    with open(path_output + '__FEM_Para_Base.txt', 'w') as f:

        # surface type
        f.write('Surfaces*\t')
        for sf in surfaces.surface_list:
            f.write('%d\t' % sf.surf_type)
        f.write('\n')

        # materials
        f.write(
            'Material*\t%s\t%e\t%d\t%e\t%e\n' %
            ('Rubber', material_para[0], material_para[1],
             material_para[2], material_para[3]))

        # Seed size
        f.write('SeedSize*\t%e\n' % seed_size)
    
    os.chdir(path_output)
    os.system('abaqus cae noGUI=' + path_output + '/GenModel.py')
    os.chdir(current_path)
    