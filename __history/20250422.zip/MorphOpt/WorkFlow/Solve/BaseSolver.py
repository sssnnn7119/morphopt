

import sys

import numpy as np
import torch
sys.path.append('..//Modules/FEA')
import FEA
import multiprocessing as mp

class BaseSolver():
    """
    This class is responsible for solving the FEA and get the displacement of the soft robot.
    """

    def __init__(self, pressure_list: list[list[float]], path_result: str, U_dim: list[int], p_dim: list[int], num_process: int = 4):
        """
        Initialize the Solver class with a list of pressure values.

        Parameters:
            pressure_list (list[list[float]]): A list of pressure values for the optimization problem.
        """
        self.pressure_list = pressure_list
        """
        list[list[float]]: A list of pressure values for the optimization problem.
        """
        
        self.inp: FEA.FEA_INP = FEA.FEA_INP()
        """
        FEA.FEA_INP: An instance of the FEA_INP class from the FEA module.
        """

        self.path_result = path_result
        """
        str: The path to the result directory.
        """

        self.num_process = num_process
        """
        int: The number of processes to use for parallel computation.
        """
        
        self.U_dim: list[int] = U_dim
        """
        list[int]: The dimensions of the interest for the optimization problem.
        """
        
        self.p_dim: list[int] = p_dim
        """
        list[int]: The dimensions of the pressure for the optimization problem.
        """

    def solve(self):
        """
        Solve the optimization problem using the specified solver.

        Returns:
            tuple: the displacement field and its derivatives:
                - points_request (torch.Tensor): The points of the sensitivity.
                    [num_gauss, num_element, U]
                - U (torch.Tensor): The displacement vector.
                    [num_task, DoF]
                - Udp (torch.Tensor): The Jacobian vector.
                    [num_task, num_pressure, DoF]
                - Udot (torch.Tensor): The sensitivity of velocity vector.
                    [num_task, num_gauss, num_element, num_surface, U]
                - Udpdot (torch.Tensor): The sensitivity of Jacobian vector.
                    [num_task, num_gauss, num_element, num_surface, U, p]
        """

        # multiprocess FEA
        # self.__class__._solve_FEA(self.__class__, self.path_result, self.pressure_list[0], [-3, -2, -1], [0])
        pools = mp.Pool(processes=4)
        result = []
        for i in range(len(self.pressure_list)):
            result.append(
                pools.apply_async(self.__class__._solve_FEA,
                                args=(self.__class__, self.path_result, self.pressure_list[i], self.U_dim, self.p_dim)))
        pools.close()
        pools.join()

        # get the result
        points_request = torch.tensor([i.get()[0] for i in result], device='cpu')[0]
        GC0_list = torch.tensor([i.get()[1] for i in result], device='cpu')
        Udp_list = torch.tensor([i.get()[2] for i in result], device='cpu')
        sen_U = torch.tensor([i.get()[3] for i in result], device='cpu')
        sen_Udp = torch.tensor([i.get()[4] for i in result], device='cpu')

        return points_request, GC0_list, Udp_list, sen_U, sen_Udp
    
    @staticmethod
    def _init_FEA(inp: FEA.FEA_INP) -> FEA.Main.FEA_Main:
        """
        Initialize the FEA class with the given input parameters.

        Parameters:
            inp (FEA.FEA_INP): The input parameters for the FEA class.

        Returns:
            FEA.Main.FEA_Main: An instance of the FEA_Main class with the given input parameters.
        """
        fe = FEA.from_inp(inp)

        # add pressure
        i=0
        while True:
            if 'surface_%d_All' % (i + 1) not in inp.part['final_model'].surfaces.keys():
                break

            pressure_elem = inp.part['final_model'].surfaces['surface_%d_All' % (i + 1)]
            fe.add_load(FEA.loads.Pressure(surface_element_index=pressure_elem, pressure=0.),
                        name='Pressure_%d' % i)
            i += 1

        # add boundary condition
        bc_dof = np.array(
            list(inp.part['final_model'].sets_nodes['surface_0_Bottom'])) * 3
        bc_dof = np.concatenate([bc_dof, bc_dof + 1, bc_dof + 2])
        fe.add_constraint(FEA.constraints.Boundary_Condition(indexDOF=bc_dof, dispValue=0.),
                        name='BC')

        # add reference point and constraints
        rp = FEA.ReferencePoint([0., 0., fe.nodes[:, 2].max()],)
        rp_name = fe.add_reference_point(rp=rp)
        indexNodes = np.where((abs(fe.nodes[:, 2] - rp.node[2])
                                < 0.1).cpu().numpy())[0]
        fe.add_constraint(FEA.constraints.Couple(indexNodes=indexNodes, rp_name=rp_name)
        )

        return fe

    @staticmethod
    def _solve_FEA(current_class: 'BaseSolver', path_result, pressure_list: list[float], U_dim: list[int], p_dim: list[int]):
        import sys
        import os
        import torch
        sys.path.append(os.getcwd())
        sys.path.append('..//Modules/FEA')
        import FEA
        from .SecondDerivativeElement import C3D10_Sensitivity

        current_process_name = mp.current_process().name
        try:
            pool_id = int(current_process_name.split("-")[-1]) % 4
        except:
            pool_id = 0

        if torch.cuda.is_available():
            
            cuda_now = pool_id % torch.cuda.device_count()
            torch.set_default_device('cuda:%d' % cuda_now)
        else:
            torch.set_default_device('cpu')

        # torch.set_default_device(torch.device('cuda:0'))
        torch.set_default_dtype(torch.float64)
        torch.cuda.empty_cache()
        # construct the FEA
        FE_inp = FEA.FEA_INP()
        FE_inp.Read_INP(path_result + '/Cache/' + '/TopOptRun.inp')

        fe = current_class._init_FEA(FE_inp)

        num_pressure = len(pressure_list)
        num_surface = num_pressure + 1

        # change the load
        for j in range(len(pressure_list)):
            fe.loads['Pressure_%d' % j].pressure = pressure_list[j]

        # solve displacement 0
        mid_nodes_index = fe.elems['element-0'].get_2nd_order_point_index()
        
        fe.nodes[mid_nodes_index[:, 0]] = (fe.nodes[mid_nodes_index[:, 1]] + fe.nodes[mid_nodes_index[:, 2]]) / 2.0
        
        fe.elems['element-0'].set_order(1)
        fe.solve(tol_error=1e-1)

        fe.elems['element-0'].set_order(2)
        fe.refine_RGC()
        fe.solve(RGC0=fe.RGC, tol_error=1e-3)

        GC0 = fe.GC.clone().detach()
        K_indices, K_values = fe._assemble_Stiffness_Matrix(
                    RGC=fe._GC2RGC(fe.GC), load_percentage=1.0)[1:]

        # calculate the jacobian
        R = torch.zeros([num_pressure, fe.RGC_list_indexStart[-1]])
        for p in range(num_pressure):
            F = torch.zeros([R.shape[1]])
            F_indice, F_values = fe.loads['Pressure_%d' % p]._get_K0_F0(fe._GC2RGC(GC0)[0])[:2]
            F.scatter_add_(0, F_indice, F_values)
            R[p, :F.numel()] = F.view([-1])
        Udp0 = fe.solve_linear_perturbation(GC0=GC0, R0=R)
        
        # define the adjoint problem
        R = torch.zeros([len(U_dim), fe.RGC_list_indexStart[-1]])
        for i in range(len(U_dim)):
            R[i, U_dim[i]] = 1

        # solve adjoint problem with displacement 0
        GCv = fe.solve_linear_perturbation(GC0=GC0, R0=-R)

        # get the derivative of the stiffness matrix with respect to the pressure
        # region for Kdp
        
        Kdp_indices = fe._assemble_Stiffness_Matrix(fe._GC2RGC(GC0))[1]

        function_udot = lambda u: fe._assemble_Stiffness_Matrix(fe._GC2RGC(u))[2]
        
        def get_Kdp(dim_now: int):
            def function_p0dot(p):
                p0 = fe.loads['Pressure_%d'%dim_now].pressure
                fe.loads['Pressure_%d'%dim_now].pressure = p
                result = fe._assemble_Stiffness_Matrix(fe._GC2RGC(fe.GC))[2]
                fe.loads['Pressure_%d'%dim_now].pressure = p0
                return result

            K0_values, Kdp1_values = torch.autograd.functional.jvp(
                function_udot, GC0, Udp0[dim_now])
            _, Kdp2_values = torch.autograd.functional.jvp(
                function_p0dot, torch.tensor([pressure_list[dim_now]], dtype=torch.float64), torch.ones([1]))

            Kdp0_values = Kdp1_values + Kdp2_values
            Kdp0 = torch.sparse_coo_tensor(Kdp_indices, Kdp0_values).coalesce()
            return Kdp0
        
        Kdp = []
        for i in range(len(p_dim)):
            Kdp.append(get_Kdp(i))

        # endregion

        # combine the results
        adjForce = torch.zeros([len(U_dim), len(p_dim), fe.RGC_list_indexStart[-1]])
        for i in range(len(U_dim)):
            for j in range(len(p_dim)):
                adjForce[i, j, fe.RGC_remain_index_flatten] = Kdp[j] @ GCv[i]

        
        # solve the second adjoint problem
        for i in range(len(p_dim)):
            fe.loads['Pressure_%d'%i].pressure = pressure_list[i]

        f = -adjForce.reshape([len(U_dim) * len(p_dim), -1])
        
        GCw = fe.solve_linear_perturbation(GC0=GC0, R0=f)
        GCw = GCw.reshape([len(U_dim), len(p_dim), -1])  # u,p
        
        # get the shape derivative
        elems = fe.elems['element-0']
        element_sensitive = C3D10_Sensitivity(
            elems_index=elems._elems_index,
            elems=elems._elems,
            fea=fe)
        materials_type = FE_inp.part['final_model'].elems_material[FE_inp.part['final_model'].elems['C3D10'][:, 0], 2].type(torch.int).unique()

        index_now = torch.where(FE_inp.part['final_model'].elems_material[FE_inp.part['final_model'].elems['C3D10'][:, 0], 2].type(torch.int) == 1)
        materials_now = FEA.materials.initialize_materials(
            materials_type=materials_type[0].item(),
            materials_params=FE_inp.part['final_model'].elems_material[FE_inp.part['final_model'].elems['C3D10'][:, 0]][index_now][:, 3:]
        )
        element_sensitive.set_materials(materials_now)

        result = []

        # # prepare the data
        J, F, invF, Ugrad, Ugrad2, s, C = element_sensitive.sensitivity_conponent(
            fe._GC2RGC(GC0)[0])
        invFdual = torch.einsum('geij, gekl-> geijkl', invF, invF)
        invFdual2 = invFdual - invFdual.transpose(3, 5)
        # calculate the sensitivity of Udp

        sen_U = torch.zeros([J.shape[0], J.shape[1], num_surface, len(U_dim)])  # surface, u
        sen_Udp = torch.zeros(
            [J.shape[0], J.shape[1], num_surface, len(U_dim), len(p_dim)])  # surface, u, p

        # calculate the sensitivity of U
        for ind_target in range(len(U_dim)):
            V_now = fe._GC2RGC_linear(GCv[ind_target])[0]
            v = element_sensitive.displacement(V_now)
            vGrad = element_sensitive.gradient_displacement(V_now)
            sen_U[:, :, :, ind_target] = \
                element_sensitive.virtual_work(s=s, Wgrad=vGrad).unsqueeze(-1)
            sen_U[:, :, 1:, ind_target] += \
                    \
                torch.einsum('s, ge, geijnm, gej, gemni->ges', torch.tensor(pressure_list), J, invFdual2, v, Ugrad2) + \
                    \
                torch.einsum('s, ge, geij, geji->ges', torch.tensor(pressure_list), J, invF, vGrad)

        # calculate the sensitivity of Udp
        for ind_pressure in range(len(p_dim)):
            Udp_now = fe._GC2RGC_linear(Udp0[ind_pressure])[0]
            Ugrad_dp = element_sensitive.gradient_displacement(Udp_now)
            Ugrad2_dp = element_sensitive.gradient_2nd_displacement(Udp_now)

            sdp = torch.einsum('geijkl, gekl->geij', C, Ugrad_dp)
            Jdp = torch.einsum('ge, gelk, gekl->ge', J, invF, Ugrad_dp)
            invFdp = -torch.einsum('geik, gelj, gekl->geij', invF, invF, Ugrad_dp)
            invFdualdp = torch.einsum('geij, gemn->geijmn', invFdp, invF)
            invFdualdp = invFdualdp + invFdualdp.transpose(2, 4).transpose(3, 5)
            invFdual2dp = invFdualdp - invFdualdp.transpose(3, 5)
            for ind_target in range(len(U_dim)):
                V_now = fe._GC2RGC_linear(GCv[ind_target])[0]
                W_now = fe._GC2RGC_linear(GCw[ind_target, ind_pressure])[0]

                v = element_sensitive.displacement(V_now)
                w = element_sensitive.displacement(W_now)
                vGrad = element_sensitive.gradient_displacement(V_now)
                wGrad = element_sensitive.gradient_displacement(W_now)

                sen_Udp[:, :, :, ind_target, ind_pressure] = \
                    element_sensitive.virtual_work(s=s, Wgrad=wGrad).unsqueeze(-1) + \
                    element_sensitive.virtual_work(s=sdp, Wgrad=vGrad).unsqueeze(-1)

                sen_Udp[:, :, ind_pressure + 1, ind_target, ind_pressure] += \
                        \
                    torch.einsum('ge, geijnm, gej, gemni->ge', J, invFdual2, v, Ugrad2) + \
                        \
                    torch.einsum('ge, geij, geji->ge', J, invF, vGrad)

                sen_Udp[:, :, 1:, ind_target, ind_pressure] += \
                        \
                    torch.einsum('s, ge, geijnm, gej, gemni->ges', torch.tensor(pressure_list), Jdp, invFdual2, v, Ugrad2) + \
                    torch.einsum('s, ge, geijnm, gej, gemni->ges', torch.tensor(pressure_list), J, invFdual2dp, v, Ugrad2) + \
                    torch.einsum('s, ge, geijnm, gej, gemni->ges', torch.tensor(pressure_list), J, invFdual2, w, Ugrad2) + \
                    torch.einsum('s, ge, geijnm, gej, gemni->ges', torch.tensor(pressure_list), J, invFdual2, v, Ugrad2_dp) + \
                        \
                    torch.einsum('s, ge, geij, geji->ges', torch.tensor(pressure_list), Jdp, invF, vGrad) + \
                    torch.einsum('s, ge, geij, geji->ges', torch.tensor(pressure_list), J, invFdp, vGrad) + \
                    torch.einsum('s, ge, geij, geji->ges', torch.tensor(pressure_list), J, invF, wGrad)


        return element_sensitive.points_request.tolist(), GC0.tolist(), Udp0.tolist(), sen_U.tolist(), sen_Udp.tolist()
