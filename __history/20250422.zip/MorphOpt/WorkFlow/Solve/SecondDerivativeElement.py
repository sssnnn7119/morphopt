
import torch
import FEA
import numpy as np

class C3D10_Sensitivity(FEA.elements.C3D10):

    def __init__(self, elems_index: np.ndarray, elems: np.ndarray,
                 fea) -> None:
        super().__init__(elems, elems_index)

        super().initialize(fea)
        shape_ii = torch.zeros([3, 3, 10, 10])

        shape_ii[0, 1, 0, 0] = 4
        shape_ii[0, 1, 4, 0] = -4
        shape_ii[0, 1, 5, 0] = 4
        shape_ii[0, 1, 6, 0] = -4
        shape_ii[0, 2, 0, 0] = 4
        shape_ii[0, 2, 4, 0] = -4
        shape_ii[0, 2, 7, 0] = -4
        shape_ii[0, 2, 8, 0] = 4
        shape_ii[1, 2, 0, 0] = 4
        shape_ii[1, 2, 6, 0] = -4
        shape_ii[1, 2, 7, 0] = -4
        shape_ii[1, 2, 9, 0] = 4

        shape_ii = shape_ii + shape_ii.transpose(0, 1)

        shape_ii[0, 0, 0, 0] = 4
        shape_ii[0, 0, 1, 0] = 4
        shape_ii[0, 0, 4, 0] = -8
        shape_ii[1, 1, 0, 0] = 4
        shape_ii[1, 1, 2, 0] = 4
        shape_ii[1, 1, 6, 0] = -8
        shape_ii[2, 2, 0, 0] = 4
        shape_ii[2, 2, 3, 0] = 4
        shape_ii[2, 2, 7, 0] = -8

        self.shape_function.append(shape_ii)

        alpha = 0.58541020
        beta = 0.13819660
        # alpha = 0.85
        # beta = 0.05
        self.point_request_ref = torch.tensor([[beta, beta, beta],
                                           [alpha, beta, beta],
                                           [beta, alpha, beta],
                                           [beta, beta, alpha]])
        # self.point_request_ref = torch.tensor([[0.25, 0.25, 0.25]])

        # self.point_request_ref = torch.tensor([
        #     [1 / 3, 1 / 3, 1 / 3],
        #     [0.0, 1 / 3, 1 / 3],
        #     [1 / 3, 0.0, 1 / 3],
        #     [1 / 3, 1 / 3, 0.0],
        #     [0.25, 0.25, 0.25]
        # ])

        p0 = self.point_request_ref
        self.pp = torch.zeros([p0.shape[0], 10])
        self.pp[:, 0] = 1
        self.pp[:, 1] = p0[:, 0]
        self.pp[:, 2] = p0[:, 1]
        self.pp[:, 3] = p0[:, 2]
        self.pp[:, 4] = p0[:, 0] * p0[:, 1]
        self.pp[:, 5] = p0[:, 1] * p0[:, 2]
        self.pp[:, 6] = p0[:, 2] * p0[:, 0]
        self.pp[:, 7] = p0[:, 0]**2
        self.pp[:, 8] = p0[:, 1]**2
        self.pp[:, 9] = p0[:, 2]**2

        self.Jacobian1 = torch.zeros([p0.shape[0], len(self._elems), 3, 3])
        self.Jacobian2 = torch.zeros([p0.shape[0], len(self._elems), 3, 3, 3])
        for i in range(10):
            self.Jacobian1 += torch.einsum('gb,mb,ei->geim', self.pp,
                                           self.shape_function[1][:, i],
                                           fea.nodes[self._elems[:, i]])
            self.Jacobian2 += torch.einsum('gb,mnb,ei->geimn', self.pp,
                                           self.shape_function[2][:, :, i],
                                           fea.nodes[self._elems[:, i]])

        self.inv_Jacobian1 = self.Jacobian1.cpu().inverse().to(self.pp.device)
        self.inv_Jacobian2 = -torch.einsum(
            'gemj,gepk,genl,gejnp->gemlk', self.inv_Jacobian1,
            self.inv_Jacobian1, self.inv_Jacobian1, self.Jacobian2)

        Nksi1 = torch.einsum('gb,mab->gma', self.pp, self.shape_function[1])
        Nksi2 = torch.einsum('gb,mnab->gmna', self.pp, self.shape_function[2])

        self.shapeFun0 = torch.einsum('ab, gb->ga', self.shape_function[0],
                                      self.pp)
        self.shapeFun1 = torch.einsum('gemi,gma->geia', self.inv_Jacobian1,
                                      Nksi1)
        self.shapeFun2 = torch.einsum(
            'gemi, genj,gmna->geija',
            self.inv_Jacobian1, self.inv_Jacobian1, Nksi2) + torch.einsum(
                'gemij, gma->geija', self.inv_Jacobian2, Nksi1)

        points_request = torch.zeros(
            [self.pp.shape[0], self._elems.shape[0], 3])
        for i in range(self._elems.shape[1]):
            points_request = points_request + torch.einsum(
                'g,eI->geI', self.shapeFun0[:, i], fea.nodes[self._elems[:,
                                                                         i]])

        self.points_request = points_request
    
    def displacement(self, U: torch.Tensor):
        Ue = torch.zeros([self.pp.shape[0], self._elems.shape[0], 3])
        for i in range(self._elems.shape[1]):
            Ue = Ue + torch.einsum('gei,eI->geI', self.shapeFun1[:, :, :, i],
                                   U[self._elems[:, i]])
        return Ue
    
    def gradient_displacement(self, U: torch.Tensor):
        Ugrad = torch.zeros([self.pp.shape[0], self._elems.shape[0], 3, 3])
        for i in range(self._elems.shape[1]):
            Ugrad = Ugrad + torch.einsum(
                'gei,eI->geIi', self.shapeFun1[:, :, :, i], U[self._elems[:,
                                                                         i]])
        return Ugrad
    
    def gradient_2nd_displacement(self, U: torch.Tensor):
        Ugrad2 = torch.zeros([self.pp.shape[0], self._elems.shape[0], 3, 3, 3])
        for i in range(self._elems.shape[1]):
            Ugrad2 = Ugrad2 + torch.einsum(
                'geij,eI->geIij', self.shapeFun2[:, :, :, :,
                                                 i], U[self._elems[:, i]])
        return Ugrad2
    
    def gradient_JFw(self, J, invF, w, Wgrad, Ugrad2):
        Jdot = torch.einsum('ge, geiI, geIij->gej', J, invF, Ugrad2)
        invFdot = -torch.einsum('geij, gejki, gekm->gem', invF, Ugrad2, invF)

        divJFW = torch.einsum(
            'geij, gej, gei->ge', invF, w, Jdot) + torch.einsum(
                'ge, gej, gej->ge', J, invFdot, w) + torch.einsum(
                    'ge, geij, geji->ge', J, invF, Wgrad)
        return divJFW
    
    def virtual_work(self, s: torch.Tensor, Wgrad: torch.Tensor):
        return (s * Wgrad.transpose(-1, -2)).sum(dim=[-1, -2])

    def sensitivity_conponent(self, U: torch.Tensor):
        Ugrad = self.gradient_displacement(U)
        Ugrad2 = self.gradient_2nd_displacement(U)

        F, I1, J, invF, s, C = self.components_Solid(U=U)
        
        return J, F, invF, Ugrad, Ugrad2, s, C

    def sensitivity(self, U: torch.Tensor, W: torch.Tensor):

        w = self.displacement(W)
        Ugrad = self.gradient_displacement(U)
        Wgrad = self.gradient_displacement(W)
        Ugrad2 = self.gradient_2nd_displacement(U)

        F = Ugrad.clone()
        F[:, :, 0, 0] += 1
        F[:, :, 1, 1] += 1
        F[:, :, 2, 2] += 1

        invF = F.inverse()
        J = F.det()
        Jneg = J**(-2 / 3)
        I1 = (F**2).sum([-1, -2]) * Jneg
        s, C = self.material_Constitutive(F, J, Jneg, invF, I1)

        sen_work = self.virtual_work(s, Wgrad)

        divJFW = self.gradient_JFw(J, invF, w, Wgrad, Ugrad2)

        return self.points_request, sen_work, divJFW
