"""
For the MorphOpt package, this module contains the parameters for the optimization process.
It includes classes for defining the parameters for the Finite Element Method (FEM) analysis, the optimization process, and the recording of the optimization history.
"""
from .FEM import FEM_para as __FEM_para
from .History import History as __History
from .Path import Path as __Path


FE = __FEM_para()
PATH = __Path()
History = __History()

__all__ = [
    'FE',
    'PATH',
    'HISTORY'
]