
class History:
    """
    A class to record the information of the optimization process.
    """

    def __init__(self):
        self.history_objective: list[float] = []
        """
        The history of the objective function values.
        """
        self.history_time: list[list[float]] = []
        """
        The history of the time taken for each iteration.
        """

        self.iteration: int = 0
        """
        The current iteration number.
        """
