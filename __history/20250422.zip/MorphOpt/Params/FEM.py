class FEM_para():
    """
    The FEM_para class is responsible for defining the parameters for the Finite Element Method (FEM) analysis.
    It contains methods to set and get the parameters for the FEM analysis.
    """
    
    def __init__(self):
        # materials [density, type:(0:linear, 1:neohooken), para:]
        self.material_para: list = [1.08e-9, 1, 0.481606, 48.0]

        # seed size
        self.seed_size: float = 0.0