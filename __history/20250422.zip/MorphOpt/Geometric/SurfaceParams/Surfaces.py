
import torch
from ..SurfaceModel.Surface_Base import Surface_Base
from ..SurfaceInterface.BaseInterface import BaseInterface

class Surfaces():
    """
    Class to handle the surfaces of the morphable model.
    """

    def __init__(self, thickness: list[float]) -> None:
        """
        Initialize the Surfaces class.

        Parameters
        ----------
        surface : str
            The name of the surface.
        """


        self.surface_list: list[BaseInterface] = []
        """
        List of surface objects.
        """
        
        self.max_step_length: list[float] = []
        """
        The maximum step length for each surface in the optimization process.
        """
        
        self.thickness: list[float] = thickness
        """
        The minimum distance between the surfaces.
        [0] : The minimum distance between the surface and itself.
        [1] : The minimum distance between the surface and the other surfaces.
        """
    
    def add_surface(self, surface_new: BaseInterface) -> None:
        """
        Add a surface object to the list.

        Parameters
        ----------
        surface : Surface
            The surface object to be added.
        """
        self.surface_list.append(surface_new)
        
    @property
    def num_surface(self) -> int:
        """
        Get the number of surfaces.

        Returns:
            length (int) :The number of surfaces.
        """
        return len(self.surface_list)
    
    def get_geometry_values(self) -> list[torch.Tensor]:
        """
        Get the geometry values of the surfaces.

        Returns:
            list[tuple]: A tuple containing the geometry values of the surfaces.
                - r (list[torch.Tensor]): The point coordinates of the surfaces.
                - rdu (list[torch.Tensor]): The partial derivatives of the surfaces.
                - rdu2 (list[torch.Tensor]): The second partial derivatives of the surfaces.
        """
        
        rlist = [self.surface_list[i].get_geometry_values() for i in range(self.num_surface)]
        r = [rlist[i][0] for i in range(self.num_surface)]
        rdu = [rlist[i][1] for i in range(self.num_surface)]
        rdu2 = [rlist[i][2] for i in range(self.num_surface)]
        return r, rdu, rdu2
    
    def get_penalty_fairness(self, weight: list[torch.Tensor], r: list[torch.Tensor], rdu: list[torch.Tensor], rdu2: list[torch.Tensor]) -> torch.Tensor:
        """
        Get the penalty fairness of the surfaces.

        Parameters:
            weight (list[torch.Tensor]): The weights for the points in the optimization process.
            r (list[torch.Tensor]): The point coordinates of the surfaces.
            rdu (list[torch.Tensor]): The partial derivatives of the surfaces.
            rdu2 (list[torch.Tensor]): The second partial derivatives of the surfaces.

        Returns:
            torch.Tensor: The penalty fairness of the surfaces.
        """
        
        penalty = 0
        for i in range(self.num_surface):
            penalty += self.surface_list[i].get_penalty_fairness(weight[i], r[i], rdu[i], rdu2[i])
        
        return penalty
    
    def get_points_weight(self) -> list[torch.Tensor]:
        """
        Get the weights for the points in the optimization process.

        Returns:
            list[torch.Tensor]: The weights for the points in the optimization process.
        """
        
        weight = [self.surface_list[i].get_points_weight() for i in range(self.num_surface)]
        return weight
    
    def get_surface_parameters(self) -> torch.Tensor:
        """
        Get the current variables of the surfaces.

        Returns:
            torch.Tensor: The current variables of the surfaces.
        """
        xlist = [self.surface_list[i].get_surface_parameters().flatten() for i in range(self.num_surface)]
        return xlist
    
    def set_surface_parameters(self, xlist: list[torch.Tensor]) -> None:
        """
        Set the current variables of the surfaces.

        Parameters:
            xlist (list[torch.Tensor]): The new variables for the surfaces.
        """
        for i in range(self.num_surface):
            self.surface_list[i].set_surface_parameters(xlist[i].detach().clone())
            
    def get_variables(self) -> torch.Tensor:
        """
        Get the current variables of the surfaces.

        Returns:
            list[torch.Tensor]: The current variables of the surfaces.
        """
        xlist = self.get_surface_parameters()
        x_flatten = torch.cat([torch.randn_like(xlist[i].flatten())*1e-6 for i in range(self.num_surface)])
        return x_flatten
    
    
    def update_variables(self, x_change: torch.Tensor) -> None:
        """
        Update the surfaces with the new variables.

        Parameters:
            xlist_change (torch.Tensor): The change of variables for the surfaces.
        """
        
        x_change_list = []
        start = 0
        for i in range(self.num_surface):
            end = start + self.surface_list[i].num_variables
            x_change_list.append(x_change[start:end].reshape([3, -1]))
            start = end
        
        x_new = []
        for i in range(self.num_surface):
            
            r = x_change_list[i].norm(dim=0)
            
            dx = 2/torch.pi * torch.atan(r) * x_change_list[i] / (r + 1e-15) * self.max_step_length[i]
            
            self.surface_list[i].update_variables(dx)