from mayavi import mlab
import numpy as np
import multiprocessing as mp


class Test:
    aa = 1
    def solve(self):
        """处理输入数据并返回多个结果
        
        Args:
            data (list): 输入数据列表
            
        Returns:
            tuple: 包含三个元素的元组，分别是:
                - processed_data (list): 处理后的数据
                - count (int): 数据项数量
                - is_valid (bool): 数据是否有效
        """
        para = [1,2,3,4]

        pools = mp.Pool(processes=4)
        result = []
        for i in range(len(para)):
            result.append(
                pools.apply_async(Test._solve,
                                args=(para[i], self.__class__)))
        pools.close()
        pools.join()
        result1 = [i.get() for i in result]
        print(result1)

    @staticmethod
    def _solve(a, b: 'Test'):
        print(a)
        print(b.aa)
        return a

if __name__ == '__main__':
    # Test the function
    tt = Test()
    tt.solve()