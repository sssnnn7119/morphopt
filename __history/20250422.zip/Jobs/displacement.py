import os
import sys

sys.path.append(os.getcwd())

import torch
from MorphOpt import Params
from MorphOpt.WorkFlow import OptLoop
from MorphOpt.Geometric.SurfaceParams.Surfaces import Surfaces
from MorphOpt.Geometric import SurfaceInterface
from MorphOpt.WorkFlow import Initialize
from MorphOpt.WorkFlow import Solve
from MorphOpt.WorkFlow import AnalyzeSensitivity
from MorphOpt.WorkFlow import Update

torch.set_default_dtype(torch.float64)
torch.set_default_device('cuda')


class SurfaceParams(Surfaces):
    pass


class Solver(Solve.BaseSolver):
    """
    Solver class for MorphOpt.
    This class is responsible for solving the finite element analysis (FEA) problem.
    """


class Analyzer(AnalyzeSensitivity.BaseAnalyzer):
    """
    Optimize the displacement of a structure using a sensitivity-based approach.
    This class is designed to work with the MorphOpt framework and is intended for use in finite element analysis (FEA) applications.
    """

    def __init__(self, surfaces):
        """
        Initialize the Displacement class.

        Parameters:
        surfaces (Surfaces): The surfaces object that contains the design variables.
        """
        super().__init__(surfaces=surfaces)

    def get_sensitivity_elems(self, U, Udp, Udot, Udpdot):

        return U[0, -2], Udot[0, :, :, :, 0]


if __name__ == '__main__':

    path_result = 'Z:/Results/'

    # region Initialize the workflow
    Initialize.initialize_path(result_path=path_result)
    Initialize.initialize_history()
    Params.FE.material_para = [1.08e-9, 1, 0.481606, 48.0]
    Params.FE.seed_size = 2.0
    # endregion

    # region Initialize the surfaces
    surfaces = SurfaceParams(thickness=[2.5, 2.5])
    surfaces.add_surface(
        SurfaceInterface.BSP.initialize_cylinder(r0=8.,
                                                 length=80.,
                                                 seed_size=1.,
                                                 symmetric=[0],
                                                 flip=False))
    surfaces.add_surface(
        SurfaceInterface.BSP.initialize_cylinder(r0=4.,
                                                 length=74.,
                                                 seed_size=1.,
                                                 symmetric=[0],
                                                 flip=True,
                                                 init_location=[0., 0., 3.]))
    # endregion
    
    # region Initialize the solver and the analyser
    solver = Solver(
        pressure_list=[[0.06]],
        path_result=Params.PATH.path_Result,
        U_dim=[-2],
        p_dim=[0],
    )
    analyser = Analyzer(surfaces=surfaces)
    # endregion

    # region Initialize the updater
    updater = Update.Updater(surfaces=surfaces)
    updater.add_objective_function(Update.ObjectiveFuncs.Sensitivity())
    updater.add_objective_function(
        Update.ObjectiveFuncs.Fairness(surfaces=surfaces))
    updater.add_objective_function(
        Update.ObjectiveFuncs.Distance(surfaces=surfaces))
    # endregion

    OptLoop.opt_loop(surfaces=surfaces,
                     solver=solver,
                     analyzer=analyser,
                     updater=updater)
